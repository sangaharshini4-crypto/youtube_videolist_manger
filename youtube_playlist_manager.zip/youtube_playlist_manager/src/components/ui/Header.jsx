import React, { useState } from 'react';
import Icon from '../AppIcon';
import Button from './Button';

const Header = ({ isAuthenticated = false, user = null, onLogout = () => {} }) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const toggleUserMenu = () => {
    setIsUserMenuOpen(!isUserMenuOpen);
  };

  const handleNavigation = (path) => {
    window.location.href = path;
    setIsMobileMenuOpen(false);
  };

  const handleLogout = () => {
    onLogout();
    setIsUserMenuOpen(false);
    window.location.href = '/login';
  };

  if (!isAuthenticated) {
    return (
      <header className="bg-card border-b border-border shadow-subtle">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                    <Icon name="Play" size={20} color="white" />
                  </div>
                  <span className="text-xl font-semibold text-foreground">
                    YouTube Playlist Manager
                  </span>
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                onClick={() => handleNavigation('/login')}
                className="text-sm"
              >
                Sign In
              </Button>
              <Button
                variant="default"
                onClick={() => handleNavigation('/register')}
                className="text-sm"
              >
                Get Started
              </Button>
            </div>
          </div>
        </div>
      </header>
    );
  }

  return (
    <header className="bg-card border-b border-border shadow-subtle fixed top-0 left-0 right-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <div className="flex items-center space-x-2 cursor-pointer" onClick={() => handleNavigation('/')}>
                <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                  <Icon name="Play" size={20} color="white" />
                </div>
                <span className="text-xl font-semibold text-foreground hidden sm:block">
                  YouTube Playlist Manager
                </span>
                <span className="text-xl font-semibold text-foreground sm:hidden">
                  YPM
                </span>
              </div>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <button
              onClick={() => handleNavigation('/')}
              className="text-foreground hover:text-primary transition-smooth px-3 py-2 rounded-md text-sm font-medium"
            >
              My Playlists
            </button>
            <button
              onClick={() => handleNavigation('/video-search-and-add')}
              className="text-foreground hover:text-primary transition-smooth px-3 py-2 rounded-md text-sm font-medium"
            >
              Add Videos
            </button>
            <button
              onClick={() => handleNavigation('/video-player')}
              className="text-foreground hover:text-primary transition-smooth px-3 py-2 rounded-md text-sm font-medium"
            >
              Player
            </button>
          </nav>

          {/* Desktop User Menu */}
          <div className="hidden md:flex items-center space-x-4">
            <div className="relative">
              <button
                onClick={toggleUserMenu}
                className="flex items-center space-x-2 text-sm rounded-full focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 p-2 hover:bg-muted transition-smooth"
              >
                <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center">
                  <Icon name="User" size={16} color="white" />
                </div>
                <span className="text-foreground font-medium">
                  {user?.name || 'User'}
                </span>
                <Icon name="ChevronDown" size={16} className="text-muted-foreground" />
              </button>

              {isUserMenuOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-popover rounded-md shadow-elevated border border-border z-50">
                  <div className="py-1">
                    <button
                      onClick={() => {
                        handleNavigation('/profile');
                        setIsUserMenuOpen(false);
                      }}
                      className="flex items-center px-4 py-2 text-sm text-popover-foreground hover:bg-muted w-full text-left transition-smooth"
                    >
                      <Icon name="Settings" size={16} className="mr-3" />
                      Account Settings
                    </button>
                    <button
                      onClick={() => {
                        handleNavigation('/help');
                        setIsUserMenuOpen(false);
                      }}
                      className="flex items-center px-4 py-2 text-sm text-popover-foreground hover:bg-muted w-full text-left transition-smooth"
                    >
                      <Icon name="HelpCircle" size={16} className="mr-3" />
                      Help & Support
                    </button>
                    <div className="border-t border-border my-1"></div>
                    <button
                      onClick={handleLogout}
                      className="flex items-center px-4 py-2 text-sm text-destructive hover:bg-muted w-full text-left transition-smooth"
                    >
                      <Icon name="LogOut" size={16} className="mr-3" />
                      Sign Out
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              onClick={toggleMobileMenu}
              className="inline-flex items-center justify-center p-2 rounded-md text-foreground hover:text-primary hover:bg-muted focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 transition-smooth"
            >
              <Icon name={isMobileMenuOpen ? "X" : "Menu"} size={24} />
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-card border-t border-border shadow-elevated">
          <div className="px-2 pt-2 pb-3 space-y-1">
            <button
              onClick={() => handleNavigation('/')}
              className="block px-3 py-2 rounded-md text-base font-medium text-foreground hover:text-primary hover:bg-muted transition-smooth w-full text-left"
            >
              My Playlists
            </button>
            <button
              onClick={() => handleNavigation('/video-search-and-add')}
              className="block px-3 py-2 rounded-md text-base font-medium text-foreground hover:text-primary hover:bg-muted transition-smooth w-full text-left"
            >
              Add Videos
            </button>
            <button
              onClick={() => handleNavigation('/video-player')}
              className="block px-3 py-2 rounded-md text-base font-medium text-foreground hover:text-primary hover:bg-muted transition-smooth w-full text-left"
            >
              Player
            </button>
          </div>
          <div className="pt-4 pb-3 border-t border-border">
            <div className="flex items-center px-5">
              <div className="w-10 h-10 bg-secondary rounded-full flex items-center justify-center">
                <Icon name="User" size={20} color="white" />
              </div>
              <div className="ml-3">
                <div className="text-base font-medium text-foreground">
                  {user?.name || 'User'}
                </div>
                <div className="text-sm text-muted-foreground">
                  {user?.email || 'user@example.com'}
                </div>
              </div>
            </div>
            <div className="mt-3 space-y-1">
              <button
                onClick={() => {
                  handleNavigation('/profile');
                  setIsMobileMenuOpen(false);
                }}
                className="flex items-center px-4 py-2 text-base font-medium text-foreground hover:text-primary hover:bg-muted transition-smooth w-full text-left"
              >
                <Icon name="Settings" size={20} className="mr-3" />
                Account Settings
              </button>
              <button
                onClick={() => {
                  handleNavigation('/help');
                  setIsMobileMenuOpen(false);
                }}
                className="flex items-center px-4 py-2 text-base font-medium text-foreground hover:text-primary hover:bg-muted transition-smooth w-full text-left"
              >
                <Icon name="HelpCircle" size={20} className="mr-3" />
                Help & Support
              </button>
              <button
                onClick={handleLogout}
                className="flex items-center px-4 py-2 text-base font-medium text-destructive hover:bg-muted transition-smooth w-full text-left"
              >
                <Icon name="LogOut" size={20} className="mr-3" />
                Sign Out
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
import React, { useState, useRef, useEffect } from 'react';
import Icon from '../AppIcon';


const VideoContextMenu = ({ 
  video = null, 
  isOpen = false, 
  onClose = () => {}, 
  position = { x: 0, y: 0 },
  playlists = [],
  onAddToPlaylist = () => {},
  onRemoveFromPlaylist = () => {},
  onEditVideo = () => {},
  onDeleteVideo = () => {},
  onShareVideo = () => {},
  onDownloadVideo = () => {}
}) => {
  const [showPlaylistSubmenu, setShowPlaylistSubmenu] = useState(false);
  const menuRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (menuRef?.current && !menuRef?.current?.contains(event?.target)) {
        onClose();
        setShowPlaylistSubmenu(false);
      }
    };

    const handleEscape = (event) => {
      if (event?.key === 'Escape') {
        onClose();
        setShowPlaylistSubmenu(false);
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      document.addEventListener('keydown', handleEscape);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleEscape);
    };
  }, [isOpen, onClose]);

  const handlePlaylistAction = (playlist, action) => {
    if (action === 'add') {
      onAddToPlaylist(video, playlist);
    } else if (action === 'remove') {
      onRemoveFromPlaylist(video, playlist);
    }
    setShowPlaylistSubmenu(false);
    onClose();
  };

  const handleMenuAction = (action) => {
    switch (action) {
      case 'edit':
        onEditVideo(video);
        break;
      case 'delete':
        onDeleteVideo(video);
        break;
      case 'share':
        onShareVideo(video);
        break;
      case 'download':
        onDownloadVideo(video);
        break;
      default:
        break;
    }
    onClose();
  };

  if (!isOpen || !video) return null;

  const menuStyle = {
    position: 'fixed',
    top: `${position?.y}px`,
    left: `${position?.x}px`,
    zIndex: 200,
  };

  return (
    <div
      ref={menuRef}
      style={menuStyle}
      className="bg-popover border border-border rounded-lg shadow-elevated min-w-48 py-1 animate-fade-in"
    >
      {/* Video Info Header */}
      <div className="px-3 py-2 border-b border-border">
        <div className="text-sm font-medium text-popover-foreground truncate">
          {video?.title || 'Video Title'}
        </div>
        <div className="text-xs text-muted-foreground font-mono">
          {video?.duration || '0:00'}
        </div>
      </div>
      {/* Quick Actions */}
      <div className="py-1">
        <button
          onClick={() => window.open(video?.url || '#', '_blank')}
          className="flex items-center w-full px-3 py-2 text-sm text-popover-foreground hover:bg-muted transition-smooth"
        >
          <Icon name="Play" size={16} className="mr-3" />
          Play Video
        </button>
        
        <button
          onClick={() => setShowPlaylistSubmenu(!showPlaylistSubmenu)}
          className="flex items-center justify-between w-full px-3 py-2 text-sm text-popover-foreground hover:bg-muted transition-smooth"
        >
          <div className="flex items-center">
            <Icon name="Plus" size={16} className="mr-3" />
            Add to Playlist
          </div>
          <Icon name="ChevronRight" size={16} />
        </button>

        {/* Playlist Submenu */}
        {showPlaylistSubmenu && (
          <div className="ml-6 border-l border-border pl-2 py-1">
            {playlists?.length > 0 ? (
              playlists?.map((playlist) => (
                <button
                  key={playlist?.id}
                  onClick={() => handlePlaylistAction(playlist, 'add')}
                  className="flex items-center w-full px-3 py-1.5 text-sm text-popover-foreground hover:bg-muted transition-smooth rounded"
                >
                  <Icon name="List" size={14} className="mr-2" />
                  <span className="truncate">{playlist?.name}</span>
                  <span className="ml-auto text-xs text-muted-foreground font-mono">
                    {playlist?.videoCount || 0}
                  </span>
                </button>
              ))
            ) : (
              <div className="px-3 py-1.5 text-sm text-muted-foreground">
                No playlists available
              </div>
            )}
            <div className="border-t border-border mt-1 pt-1">
              <button
                onClick={() => {
                  // Handle create new playlist
                  setShowPlaylistSubmenu(false);
                  onClose();
                }}
                className="flex items-center w-full px-3 py-1.5 text-sm text-primary hover:bg-muted transition-smooth rounded"
              >
                <Icon name="PlusCircle" size={14} className="mr-2" />
                Create New Playlist
              </button>
            </div>
          </div>
        )}
      </div>
      <div className="border-t border-border my-1"></div>
      {/* Management Actions */}
      <div className="py-1">
        <button
          onClick={() => handleMenuAction('edit')}
          className="flex items-center w-full px-3 py-2 text-sm text-popover-foreground hover:bg-muted transition-smooth"
        >
          <Icon name="Edit" size={16} className="mr-3" />
          Edit Details
        </button>
        
        <button
          onClick={() => handleMenuAction('share')}
          className="flex items-center w-full px-3 py-2 text-sm text-popover-foreground hover:bg-muted transition-smooth"
        >
          <Icon name="Share" size={16} className="mr-3" />
          Share Video
        </button>
        
        <button
          onClick={() => handleMenuAction('download')}
          className="flex items-center w-full px-3 py-2 text-sm text-popover-foreground hover:bg-muted transition-smooth"
        >
          <Icon name="Download" size={16} className="mr-3" />
          Download Info
        </button>
      </div>
      <div className="border-t border-border my-1"></div>
      {/* Destructive Actions */}
      <div className="py-1">
        <button
          onClick={() => handleMenuAction('delete')}
          className="flex items-center w-full px-3 py-2 text-sm text-destructive hover:bg-muted transition-smooth"
        >
          <Icon name="Trash2" size={16} className="mr-3" />
          Remove Video
        </button>
      </div>
    </div>
  );
};

export default VideoContextMenu;
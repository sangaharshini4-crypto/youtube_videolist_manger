import React, { useState, useRef, useEffect } from 'react';
import Icon from '../AppIcon';
import Button from './Button';
import Input from './Input';

const PlaylistQuickActions = ({ 
  isVisible = true,
  position = 'floating', // 'floating', 'sidebar', 'sticky'
  recentPlaylists = [],
  onCreatePlaylist = () => {},
  onSelectPlaylist = () => {},
  onQuickAdd = () => {},
  selectedVideos = [],
  className = ''
}) => {
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [newPlaylistName, setNewPlaylistName] = useState('');
  const [newPlaylistDescription, setNewPlaylistDescription] = useState('');
  const [isExpanded, setIsExpanded] = useState(false);
  const modalRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (modalRef?.current && !modalRef?.current?.contains(event?.target)) {
        setIsCreateModalOpen(false);
        setNewPlaylistName('');
        setNewPlaylistDescription('');
      }
    };

    const handleEscape = (event) => {
      if (event?.key === 'Escape') {
        setIsCreateModalOpen(false);
        setNewPlaylistName('');
        setNewPlaylistDescription('');
      }
    };

    if (isCreateModalOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      document.addEventListener('keydown', handleEscape);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleEscape);
    };
  }, [isCreateModalOpen]);

  const handleCreatePlaylist = () => {
    if (newPlaylistName?.trim()) {
      onCreatePlaylist({
        name: newPlaylistName?.trim(),
        description: newPlaylistDescription?.trim(),
        videos: selectedVideos
      });
      setIsCreateModalOpen(false);
      setNewPlaylistName('');
      setNewPlaylistDescription('');
    }
  };

  const handleQuickAddToPlaylist = (playlist) => {
    onQuickAdd(selectedVideos, playlist);
  };

  if (!isVisible) return null;

  const getPositionClasses = () => {
    switch (position) {
      case 'floating':
        return 'fixed bottom-6 right-6 z-40';
      case 'sidebar':
        return 'sticky top-4';
      case 'sticky':
        return 'sticky top-20 z-30';
      default:
        return '';
    }
  };

  return (
    <>
      <div className={`${getPositionClasses()} ${className}`}>
        <div className="bg-card border border-border rounded-lg shadow-elevated p-4 min-w-64 max-w-80">
          {/* Header */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <Icon name="Zap" size={20} className="text-accent" />
              <h3 className="text-sm font-medium text-foreground">Quick Actions</h3>
            </div>
            {position === 'floating' && (
              <button
                onClick={() => setIsExpanded(!isExpanded)}
                className="p-1 hover:bg-muted rounded transition-smooth"
              >
                <Icon name={isExpanded ? "ChevronDown" : "ChevronUp"} size={16} />
              </button>
            )}
          </div>

          {/* Selected Videos Count */}
          {selectedVideos?.length > 0 && (
            <div className="mb-4 p-2 bg-muted rounded-md">
              <div className="flex items-center space-x-2">
                <Icon name="CheckCircle" size={16} className="text-success" />
                <span className="text-sm text-foreground">
                  {selectedVideos?.length} video{selectedVideos?.length !== 1 ? 's' : ''} selected
                </span>
              </div>
            </div>
          )}

          {/* Quick Actions */}
          <div className={`space-y-3 ${position === 'floating' && !isExpanded ? 'hidden' : ''}`}>
            {/* Create New Playlist */}
            <Button
              variant="default"
              fullWidth
              iconName="Plus"
              iconPosition="left"
              onClick={() => setIsCreateModalOpen(true)}
              className="justify-start"
            >
              Create New Playlist
            </Button>

            {/* Recent Playlists */}
            {recentPlaylists?.length > 0 && (
              <div>
                <h4 className="text-xs font-medium text-muted-foreground mb-2 uppercase tracking-wide">
                  Recent Playlists
                </h4>
                <div className="space-y-1">
                  {recentPlaylists?.slice(0, 3)?.map((playlist) => (
                    <button
                      key={playlist?.id}
                      onClick={() => handleQuickAddToPlaylist(playlist)}
                      className="flex items-center justify-between w-full p-2 text-sm text-foreground hover:bg-muted rounded transition-smooth"
                      disabled={selectedVideos?.length === 0}
                    >
                      <div className="flex items-center space-x-2 flex-1 min-w-0">
                        <Icon name="List" size={14} className="text-muted-foreground flex-shrink-0" />
                        <span className="truncate">{playlist?.name}</span>
                      </div>
                      <div className="flex items-center space-x-2 flex-shrink-0">
                        <span className="text-xs text-muted-foreground font-mono">
                          {playlist?.videoCount || 0}
                        </span>
                        <Icon name="Plus" size={12} className="text-accent" />
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Bulk Actions */}
            {selectedVideos?.length > 1 && (
              <div>
                <h4 className="text-xs font-medium text-muted-foreground mb-2 uppercase tracking-wide">
                  Bulk Actions
                </h4>
                <div className="grid grid-cols-2 gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    iconName="Download"
                    iconPosition="left"
                    onClick={() => {/* Handle bulk download */}}
                  >
                    Export
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    iconName="Share"
                    iconPosition="left"
                    onClick={() => {/* Handle bulk share */}}
                  >
                    Share
                  </Button>
                </div>
              </div>
            )}
          </div>

          {/* Collapsed State */}
          {position === 'floating' && !isExpanded && (
            <div className="text-center">
              <Button
                variant="ghost"
                size="sm"
                iconName="ChevronUp"
                onClick={() => setIsExpanded(true)}
              >
                Show Actions
              </Button>
            </div>
          )}
        </div>
      </div>
      {/* Create Playlist Modal */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div
            ref={modalRef}
            className="bg-card border border-border rounded-lg shadow-modal w-full max-w-md animate-fade-in"
          >
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-foreground">Create New Playlist</h2>
                <button
                  onClick={() => setIsCreateModalOpen(false)}
                  className="p-1 hover:bg-muted rounded transition-smooth"
                >
                  <Icon name="X" size={20} />
                </button>
              </div>

              <div className="space-y-4">
                <Input
                  label="Playlist Name"
                  type="text"
                  placeholder="Enter playlist name"
                  value={newPlaylistName}
                  onChange={(e) => setNewPlaylistName(e?.target?.value)}
                  required
                />

                <Input
                  label="Description (Optional)"
                  type="text"
                  placeholder="Add a description for your playlist"
                  value={newPlaylistDescription}
                  onChange={(e) => setNewPlaylistDescription(e?.target?.value)}
                />

                {selectedVideos?.length > 0 && (
                  <div className="p-3 bg-muted rounded-md">
                    <div className="flex items-center space-x-2">
                      <Icon name="Info" size={16} className="text-primary" />
                      <span className="text-sm text-foreground">
                        {selectedVideos?.length} selected video{selectedVideos?.length !== 1 ? 's' : ''} will be added
                      </span>
                    </div>
                  </div>
                )}
              </div>

              <div className="flex justify-end space-x-3 mt-6">
                <Button
                  variant="outline"
                  onClick={() => setIsCreateModalOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  variant="default"
                  onClick={handleCreatePlaylist}
                  disabled={!newPlaylistName?.trim()}
                  iconName="Plus"
                  iconPosition="left"
                >
                  Create Playlist
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default PlaylistQuickActions;
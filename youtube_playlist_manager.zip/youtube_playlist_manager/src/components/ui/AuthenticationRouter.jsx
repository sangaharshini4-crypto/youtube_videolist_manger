import React, { useState, useEffect } from 'react';
import Icon from '../AppIcon';
import Button from './Button';
import Input from './Input';

const AuthenticationRouter = ({ 
  initialMode = 'login', // 'login', 'register', 'forgot-password'
  onAuthenticated = () => {},
  onModeChange = () => {},
  isLoading = false 
}) => {
  const [mode, setMode] = useState(initialMode);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    confirmPassword: '',
    name: '',
    acceptTerms: false
  });
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    setMode(initialMode);
  }, [initialMode]);

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    
    // Clear error when user starts typing
    if (errors?.[field]) {
      setErrors(prev => ({
        ...prev,
        [field]: ''
      }));
    }
  };

  const validateForm = () => {
    const newErrors = {};

    // Email validation
    if (!formData?.email) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/?.test(formData?.email)) {
      newErrors.email = 'Please enter a valid email address';
    }

    // Password validation
    if (mode !== 'forgot-password') {
      if (!formData?.password) {
        newErrors.password = 'Password is required';
      } else if (formData?.password?.length < 6) {
        newErrors.password = 'Password must be at least 6 characters';
      }
    }

    // Register-specific validations
    if (mode === 'register') {
      if (!formData?.name) {
        newErrors.name = 'Name is required';
      }
      
      if (!formData?.confirmPassword) {
        newErrors.confirmPassword = 'Please confirm your password';
      } else if (formData?.password !== formData?.confirmPassword) {
        newErrors.confirmPassword = 'Passwords do not match';
      }
      
      if (!formData?.acceptTerms) {
        newErrors.acceptTerms = 'You must accept the terms and conditions';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors)?.length === 0;
  };

  const handleSubmit = async (e) => {
    e?.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      if (mode === 'forgot-password') {
        // Handle password reset
        alert('Password reset link sent to your email');
        setMode('login');
      } else {
        // Handle login/register
        onAuthenticated({
          email: formData?.email,
          name: formData?.name || formData?.email?.split('@')?.[0],
          mode
        });
      }
    } catch (error) {
      setErrors({ submit: 'An error occurred. Please try again.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleModeChange = (newMode) => {
    setMode(newMode);
    setErrors({});
    setFormData({
      email: formData?.email, // Keep email when switching modes
      password: '',
      confirmPassword: '',
      name: '',
      acceptTerms: false
    });
    onModeChange(newMode);
  };

  const renderLoginForm = () => (
    <div className="space-y-4">
      <Input
        label="Email Address"
        type="email"
        placeholder="Enter your email"
        value={formData?.email}
        onChange={(e) => handleInputChange('email', e?.target?.value)}
        error={errors?.email}
        required
      />

      <Input
        label="Password"
        type="password"
        placeholder="Enter your password"
        value={formData?.password}
        onChange={(e) => handleInputChange('password', e?.target?.value)}
        error={errors?.password}
        required
      />

      <div className="flex items-center justify-between">
        <label className="flex items-center space-x-2">
          <input
            type="checkbox"
            className="w-4 h-4 text-primary border-border rounded focus:ring-ring"
          />
          <span className="text-sm text-foreground">Remember me</span>
        </label>
        <button
          type="button"
          onClick={() => handleModeChange('forgot-password')}
          className="text-sm text-primary hover:text-primary/80 transition-smooth"
        >
          Forgot password?
        </button>
      </div>

      <Button
        type="submit"
        variant="default"
        fullWidth
        loading={isSubmitting}
        iconName="LogIn"
        iconPosition="left"
      >
        Sign In
      </Button>

      {errors?.submit && (
        <div className="p-3 bg-error/10 border border-error/20 rounded-md">
          <p className="text-sm text-error">{errors?.submit}</p>
        </div>
      )}

      <div className="text-center">
        <span className="text-sm text-muted-foreground">Don't have an account? </span>
        <button
          type="button"
          onClick={() => handleModeChange('register')}
          className="text-sm text-primary hover:text-primary/80 transition-smooth font-medium"
        >
          Sign up
        </button>
      </div>
    </div>
  );

  const renderRegisterForm = () => (
    <div className="space-y-4">
      <Input
        label="Full Name"
        type="text"
        placeholder="Enter your full name"
        value={formData?.name}
        onChange={(e) => handleInputChange('name', e?.target?.value)}
        error={errors?.name}
        required
      />

      <Input
        label="Email Address"
        type="email"
        placeholder="Enter your email"
        value={formData?.email}
        onChange={(e) => handleInputChange('email', e?.target?.value)}
        error={errors?.email}
        required
      />

      <Input
        label="Password"
        type="password"
        placeholder="Create a password"
        value={formData?.password}
        onChange={(e) => handleInputChange('password', e?.target?.value)}
        error={errors?.password}
        description="Must be at least 6 characters"
        required
      />

      <Input
        label="Confirm Password"
        type="password"
        placeholder="Confirm your password"
        value={formData?.confirmPassword}
        onChange={(e) => handleInputChange('confirmPassword', e?.target?.value)}
        error={errors?.confirmPassword}
        required
      />

      <div className="space-y-3">
        <label className="flex items-start space-x-3">
          <input
            type="checkbox"
            checked={formData?.acceptTerms}
            onChange={(e) => handleInputChange('acceptTerms', e?.target?.checked)}
            className="w-4 h-4 text-primary border-border rounded focus:ring-ring mt-0.5"
          />
          <span className="text-sm text-foreground">
            I agree to the{' '}
            <a href="#" className="text-primary hover:text-primary/80 transition-smooth">
              Terms of Service
            </a>{' '}
            and{' '}
            <a href="#" className="text-primary hover:text-primary/80 transition-smooth">
              Privacy Policy
            </a>
          </span>
        </label>
        {errors?.acceptTerms && (
          <p className="text-sm text-error">{errors?.acceptTerms}</p>
        )}
      </div>

      <Button
        type="submit"
        variant="default"
        fullWidth
        loading={isSubmitting}
        iconName="UserPlus"
        iconPosition="left"
      >
        Create Account
      </Button>

      {errors?.submit && (
        <div className="p-3 bg-error/10 border border-error/20 rounded-md">
          <p className="text-sm text-error">{errors?.submit}</p>
        </div>
      )}

      <div className="text-center">
        <span className="text-sm text-muted-foreground">Already have an account? </span>
        <button
          type="button"
          onClick={() => handleModeChange('login')}
          className="text-sm text-primary hover:text-primary/80 transition-smooth font-medium"
        >
          Sign in
        </button>
      </div>
    </div>
  );

  const renderForgotPasswordForm = () => (
    <div className="space-y-4">
      <div className="text-center mb-6">
        <Icon name="Mail" size={48} className="text-muted-foreground mx-auto mb-4" />
        <p className="text-sm text-muted-foreground">
          Enter your email address and we'll send you a link to reset your password.
        </p>
      </div>

      <Input
        label="Email Address"
        type="email"
        placeholder="Enter your email"
        value={formData?.email}
        onChange={(e) => handleInputChange('email', e?.target?.value)}
        error={errors?.email}
        required
      />

      <Button
        type="submit"
        variant="default"
        fullWidth
        loading={isSubmitting}
        iconName="Send"
        iconPosition="left"
      >
        Send Reset Link
      </Button>

      {errors?.submit && (
        <div className="p-3 bg-error/10 border border-error/20 rounded-md">
          <p className="text-sm text-error">{errors?.submit}</p>
        </div>
      )}

      <div className="text-center">
        <button
          type="button"
          onClick={() => handleModeChange('login')}
          className="text-sm text-primary hover:text-primary/80 transition-smooth font-medium"
        >
          Back to sign in
        </button>
      </div>
    </div>
  );

  const getTitle = () => {
    switch (mode) {
      case 'register':
        return 'Create Your Account';
      case 'forgot-password':
        return 'Reset Password';
      default:
        return 'Welcome Back';
    }
  };

  const getSubtitle = () => {
    switch (mode) {
      case 'register':
        return 'Start organizing your YouTube playlists';
      case 'forgot-password':
        return 'We\'ll help you get back to your playlists';
      default:
        return 'Sign in to manage your playlists';
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo and Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center">
              <Icon name="Play" size={24} color="white" />
            </div>
            <span className="text-2xl font-semibold text-foreground">
              YouTube Playlist Manager
            </span>
          </div>
          <h1 className="text-2xl font-semibold text-foreground mb-2">
            {getTitle()}
          </h1>
          <p className="text-muted-foreground">
            {getSubtitle()}
          </p>
        </div>

        {/* Form Card */}
        <div className="bg-card border border-border rounded-lg shadow-subtle p-6">
          <form onSubmit={handleSubmit}>
            {mode === 'login' && renderLoginForm()}
            {mode === 'register' && renderRegisterForm()}
            {mode === 'forgot-password' && renderForgotPasswordForm()}
          </form>
        </div>

        {/* Footer */}
        <div className="text-center mt-8">
          <p className="text-xs text-muted-foreground">
            © 2025 YouTube Playlist Manager. All rights reserved.
          </p>
        </div>
      </div>
    </div>
  );
};

export default AuthenticationRouter;
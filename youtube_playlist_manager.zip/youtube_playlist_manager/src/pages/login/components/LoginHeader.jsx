import React from 'react';
import Icon from '../../../components/AppIcon';

const LoginHeader = () => {
  return (
    <div className="text-center mb-8">
      {/* Logo */}
      <div className="flex items-center justify-center space-x-3 mb-6">
        <div className="w-12 h-12 bg-primary rounded-xl flex items-center justify-center shadow-elevated">
          <Icon name="Play" size={28} color="white" />
        </div>
        <div className="text-left">
          <h1 className="text-2xl font-semibold text-foreground">
            YouTube Playlist Manager
          </h1>
          <p className="text-sm text-muted-foreground">
            Organize your video collections
          </p>
        </div>
      </div>

      {/* Welcome Message */}
      <div className="space-y-2">
        <h2 className="text-2xl font-semibold text-foreground">
          Welcome Back
        </h2>
        <p className="text-muted-foreground">
          Sign in to access your personalized video playlists and continue organizing your content
        </p>
      </div>
    </div>
  );
};

export default LoginHeader;
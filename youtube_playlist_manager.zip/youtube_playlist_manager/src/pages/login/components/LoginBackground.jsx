import React from 'react';
import Icon from '../../../components/AppIcon';

const LoginBackground = () => {
  const features = [
    {
      icon: "List",
      title: "Organize Playlists",
      description: "Create custom playlists grouped by topics and categories"
    },
    {
      icon: "Search",
      title: "Smart Search",
      description: "Find and add videos quickly with advanced search features"
    },
    {
      icon: "Play",
      title: "Seamless Playback",
      description: "Watch videos directly within the application interface"
    },
    {
      icon: "Share",
      title: "Easy Sharing",
      description: "Share your curated playlists with colleagues and friends"
    }
  ];

  return (
    <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-primary/5 to-accent/5 relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-10 left-10 w-32 h-32 bg-primary rounded-full"></div>
        <div className="absolute top-40 right-20 w-24 h-24 bg-accent rounded-full"></div>
        <div className="absolute bottom-20 left-20 w-40 h-40 bg-secondary rounded-full"></div>
        <div className="absolute bottom-40 right-10 w-20 h-20 bg-primary rounded-full"></div>
      </div>
      {/* Content */}
      <div className="relative z-10 flex flex-col justify-center p-12 w-full">
        <div className="max-w-md">
          <h3 className="text-3xl font-semibold text-foreground mb-4">
            Manage Your Video Collections Like Never Before
          </h3>
          <p className="text-lg text-muted-foreground mb-8">
            Transform how you organize, discover, and share YouTube content with our powerful playlist management tools.
          </p>

          {/* Features List */}
          <div className="space-y-6">
            {features?.map((feature, index) => (
              <div key={index} className="flex items-start space-x-4">
                <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Icon name={feature?.icon} size={20} className="text-primary" />
                </div>
                <div>
                  <h4 className="font-medium text-foreground mb-1">
                    {feature?.title}
                  </h4>
                  <p className="text-sm text-muted-foreground">
                    {feature?.description}
                  </p>
                </div>
              </div>
            ))}
          </div>

          {/* Stats */}
          <div className="mt-12 pt-8 border-t border-border">
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <div className="text-2xl font-semibold text-primary">10K+</div>
                <div className="text-xs text-muted-foreground">Active Users</div>
              </div>
              <div>
                <div className="text-2xl font-semibold text-primary">50K+</div>
                <div className="text-xs text-muted-foreground">Playlists Created</div>
              </div>
              <div>
                <div className="text-2xl font-semibold text-primary">1M+</div>
                <div className="text-xs text-muted-foreground">Videos Organized</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginBackground;
import React from 'react';
import Icon from '../../../components/AppIcon';

const SecurityBadges = () => {
  const securityFeatures = [
    {
      icon: "Shield",
      text: "SSL Encrypted"
    },
    {
      icon: "Lock",
      text: "Secure Login"
    },
    {
      icon: "Eye",
      text: "Privacy Protected"
    }
  ];

  return (
    <div className="mt-8 pt-6 border-t border-border">
      {/* Security Features */}
      <div className="flex items-center justify-center space-x-6 mb-4">
        {securityFeatures?.map((feature, index) => (
          <div key={index} className="flex items-center space-x-2">
            <Icon name={feature?.icon} size={16} className="text-success" />
            <span className="text-xs text-muted-foreground">
              {feature?.text}
            </span>
          </div>
        ))}
      </div>
      {/* Privacy Policy Links */}
      <div className="text-center space-y-2">
        <div className="flex items-center justify-center space-x-4 text-xs text-muted-foreground">
          <a 
            href="#" 
            className="hover:text-primary transition-smooth"
          >
            Privacy Policy
          </a>
          <span>•</span>
          <a 
            href="#" 
            className="hover:text-primary transition-smooth"
          >
            Terms of Service
          </a>
          <span>•</span>
          <a 
            href="#" 
            className="hover:text-primary transition-smooth"
          >
            Help Center
          </a>
        </div>
        <p className="text-xs text-muted-foreground">
          © {new Date()?.getFullYear()} YouTube Playlist Manager. All rights reserved.
        </p>
      </div>
    </div>
  );
};

export default SecurityBadges;
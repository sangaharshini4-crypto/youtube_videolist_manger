import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import LoginHeader from './components/LoginHeader';
import LoginForm from './components/LoginForm';
import SecurityBadges from './components/SecurityBadges';
import LoginBackground from './components/LoginBackground';

const LoginPage = () => {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    // Check if user is already authenticated
    const token = localStorage.getItem('authToken');
    if (token) {
      setIsAuthenticated(true);
      navigate('/video-search-and-add');
    }
  }, [navigate]);

  const handleLogin = async (formData) => {
    setIsLoading(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Store authentication data
      const userData = {
        email: formData?.email,
        name: formData?.email?.split('@')?.[0],
        loginTime: new Date()?.toISOString(),
        rememberMe: formData?.rememberMe
      };
      
      localStorage.setItem('authToken', 'mock-jwt-token-' + Date.now());
      localStorage.setItem('userData', JSON.stringify(userData));
      
      setIsAuthenticated(true);
      
      // Navigate to main application
      navigate('/video-search-and-add');
      
    } catch (error) {
      console.error('Login error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleForgotPassword = () => {
    // In a real app, this would navigate to forgot password page
    alert('Password reset functionality would be implemented here. For demo, use: admin@youtube.com / admin123');
  };

  const handleCreateAccount = () => {
    navigate('/register');
  };

  if (isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Redirecting to your dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex">
      {/* Left Side - Login Form */}
      <div className="flex-1 lg:w-1/2 flex items-center justify-center p-4 sm:p-6 lg:p-8">
        <div className="w-full max-w-md space-y-8">
          <LoginHeader />
          
          <div className="bg-card border border-border rounded-xl shadow-elevated p-6 sm:p-8">
            <LoginForm
              onSubmit={handleLogin}
              onForgotPassword={handleForgotPassword}
              onCreateAccount={handleCreateAccount}
              isLoading={isLoading}
            />
          </div>
          
          <SecurityBadges />
        </div>
      </div>

      {/* Right Side - Background/Features (Desktop Only) */}
      <LoginBackground />
    </div>
  );
};

export default LoginPage;
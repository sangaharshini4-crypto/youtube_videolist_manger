import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';
import { Checkbox } from '../../../components/ui/Checkbox';

const VideoSearchResults = ({ 
  videos = [],
  isLoading = false,
  onAddToPlaylist = () => {},
  onBulkAdd = () => {},
  playlists = [],
  selectedVideos = [],
  onVideoSelect = () => {},
  onPreview = () => {}
}) => {
  const [viewMode, setViewMode] = useState('grid'); // 'grid' or 'list'
  const [bulkPlaylist, setBulkPlaylist] = useState('');

  const formatDuration = (duration) => {
    if (!duration) return '0:00';
    const minutes = Math.floor(duration / 60);
    const seconds = duration % 60;
    return `${minutes}:${seconds?.toString()?.padStart(2, '0')}`;
  };

  const formatViewCount = (count) => {
    if (!count) return '0 views';
    if (count >= 1000000) {
      return `${(count / 1000000)?.toFixed(1)}M views`;
    }
    if (count >= 1000) {
      return `${(count / 1000)?.toFixed(1)}K views`;
    }
    return `${count} views`;
  };

  const handleBulkAdd = () => {
    if (selectedVideos?.length > 0 && bulkPlaylist) {
      const playlist = playlists?.find(p => p?.id === bulkPlaylist);
      onBulkAdd(selectedVideos, playlist);
      setBulkPlaylist('');
    }
  };

  const playlistOptions = playlists?.map(playlist => ({
    value: playlist?.id,
    label: playlist?.name,
    description: `${playlist?.videoCount || 0} videos`
  }));

  if (isLoading) {
    return (
      <div className="bg-card border border-border rounded-lg p-8">
        <div className="flex flex-col items-center justify-center space-y-4">
          <div className="animate-spin">
            <Icon name="Loader2" size={32} className="text-primary" />
          </div>
          <p className="text-muted-foreground">Searching for videos...</p>
        </div>
      </div>
    );
  }

  if (videos?.length === 0) {
    return (
      <div className="bg-card border border-border rounded-lg p-8">
        <div className="flex flex-col items-center justify-center space-y-4">
          <Icon name="Search" size={48} className="text-muted-foreground" />
          <div className="text-center">
            <h3 className="text-lg font-medium text-foreground mb-2">No videos found</h3>
            <p className="text-muted-foreground">Try adjusting your search terms or filters</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card border border-border rounded-lg">
      {/* Results Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <div className="flex items-center space-x-4">
          <h3 className="text-sm font-medium text-foreground">
            {videos?.length} video{videos?.length !== 1 ? 's' : ''} found
          </h3>
          {selectedVideos?.length > 0 && (
            <div className="flex items-center space-x-2">
              <span className="text-sm text-primary font-medium">
                {selectedVideos?.length} selected
              </span>
              <div className="flex items-center space-x-2">
                <Select
                  placeholder="Choose playlist"
                  options={playlistOptions}
                  value={bulkPlaylist}
                  onChange={setBulkPlaylist}
                  className="min-w-40"
                />
                <Button
                  variant="default"
                  size="sm"
                  onClick={handleBulkAdd}
                  disabled={!bulkPlaylist}
                  iconName="Plus"
                  iconPosition="left"
                >
                  Add Selected
                </Button>
              </div>
            </div>
          )}
        </div>
        
        <div className="flex items-center space-x-2">
          <Button
            variant={viewMode === 'grid' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setViewMode('grid')}
          >
            <Icon name="Grid3X3" size={16} />
          </Button>
          <Button
            variant={viewMode === 'list' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setViewMode('list')}
          >
            <Icon name="List" size={16} />
          </Button>
        </div>
      </div>
      {/* Results Grid/List */}
      <div className="p-4">
        {viewMode === 'grid' ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {videos?.map((video) => (
              <div key={video?.id} className="bg-background border border-border rounded-lg overflow-hidden hover:shadow-elevated transition-smooth">
                <div className="relative">
                  <div className="aspect-video overflow-hidden">
                    <Image
                      src={video?.thumbnail || `https://img.youtube.com/vi/${video?.id}/maxresdefault.jpg`}
                      alt={video?.title}
                      className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                  <div className="absolute top-2 left-2">
                    <Checkbox
                      checked={selectedVideos?.includes(video?.id)}
                      onChange={(e) => onVideoSelect(video?.id, e?.target?.checked)}
                      className="bg-black bg-opacity-50 rounded"
                    />
                  </div>
                  <div className="absolute bottom-2 right-2 bg-black bg-opacity-75 text-white text-xs px-2 py-1 rounded">
                    {formatDuration(video?.duration)}
                  </div>
                  <button
                    onClick={() => onPreview(video)}
                    className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-0 hover:bg-opacity-30 transition-all duration-200"
                  >
                    <Icon name="Play" size={32} className="text-white opacity-0 hover:opacity-100 transition-opacity" />
                  </button>
                </div>
                
                <div className="p-3">
                  <h4 className="text-sm font-medium text-foreground line-clamp-2 mb-2">
                    {video?.title}
                  </h4>
                  <div className="flex items-center space-x-2 text-xs text-muted-foreground mb-2">
                    <span>{video?.channelTitle}</span>
                    <span>•</span>
                    <span>{formatViewCount(video?.viewCount)}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">
                      {new Date(video.publishedAt)?.toLocaleDateString()}
                    </span>
                    <Select
                      placeholder="Add to..."
                      options={playlistOptions}
                      value=""
                      onChange={(playlistId) => {
                        const playlist = playlists?.find(p => p?.id === playlistId);
                        onAddToPlaylist(video, playlist);
                      }}
                      className="min-w-24"
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="space-y-3">
            {videos?.map((video) => (
              <div key={video?.id} className="flex items-center space-x-4 p-3 bg-background border border-border rounded-lg hover:shadow-elevated transition-smooth">
                <Checkbox
                  checked={selectedVideos?.includes(video?.id)}
                  onChange={(e) => onVideoSelect(video?.id, e?.target?.checked)}
                />
                
                <div className="relative flex-shrink-0">
                  <div className="w-32 h-18 overflow-hidden rounded">
                    <Image
                      src={video?.thumbnail || `https://img.youtube.com/vi/${video?.id}/maxresdefault.jpg`}
                      alt={video?.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="absolute bottom-1 right-1 bg-black bg-opacity-75 text-white text-xs px-1 py-0.5 rounded">
                    {formatDuration(video?.duration)}
                  </div>
                </div>
                
                <div className="flex-1 min-w-0">
                  <h4 className="text-sm font-medium text-foreground line-clamp-1 mb-1">
                    {video?.title}
                  </h4>
                  <div className="flex items-center space-x-2 text-xs text-muted-foreground mb-1">
                    <span>{video?.channelTitle}</span>
                    <span>•</span>
                    <span>{formatViewCount(video?.viewCount)}</span>
                    <span>•</span>
                    <span>{new Date(video.publishedAt)?.toLocaleDateString()}</span>
                  </div>
                  <p className="text-xs text-muted-foreground line-clamp-2">
                    {video?.description}
                  </p>
                </div>
                
                <div className="flex items-center space-x-2 flex-shrink-0">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onPreview(video)}
                    iconName="Play"
                  >
                    Preview
                  </Button>
                  <Select
                    placeholder="Add to..."
                    options={playlistOptions}
                    value=""
                    onChange={(playlistId) => {
                      const playlist = playlists?.find(p => p?.id === playlistId);
                      onAddToPlaylist(video, playlist);
                    }}
                    className="min-w-32"
                  />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default VideoSearchResults;
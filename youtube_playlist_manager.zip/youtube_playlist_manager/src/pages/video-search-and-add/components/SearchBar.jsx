import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const SearchBar = ({ 
  onSearch = () => {},
  onUrlAdd = () => {},
  searchQuery = '',
  isLoading = false,
  recentSearches = []
}) => {
  const [query, setQuery] = useState(searchQuery);
  const [isUrlMode, setIsUrlMode] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(false);

  const handleSearch = (e) => {
    e?.preventDefault();
    if (query?.trim()) {
      if (isUrlMode && (query?.includes('youtube.com') || query?.includes('youtu.be'))) {
        onUrlAdd(query?.trim());
      } else {
        onSearch(query?.trim());
      }
      setShowSuggestions(false);
    }
  };

  const handleInputChange = (e) => {
    const value = e?.target?.value;
    setQuery(value);
    setShowSuggestions(value?.length > 0 && recentSearches?.length > 0);
  };

  const handleSuggestionClick = (suggestion) => {
    setQuery(suggestion);
    setShowSuggestions(false);
    onSearch(suggestion);
  };

  const toggleMode = () => {
    setIsUrlMode(!isUrlMode);
    setQuery('');
    setShowSuggestions(false);
  };

  return (
    <div className="relative">
      <form onSubmit={handleSearch} className="flex items-center space-x-3">
        <div className="flex-1 relative">
          <Input
            type="text"
            placeholder={isUrlMode ? "Paste YouTube URL here..." : "Search for videos..."}
            value={query}
            onChange={handleInputChange}
            onFocus={() => setShowSuggestions(query?.length > 0 && recentSearches?.length > 0)}
            className="pr-12"
          />
          <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
            <Icon 
              name={isUrlMode ? "Link" : "Search"} 
              size={20} 
              className="text-muted-foreground" 
            />
          </div>
        </div>
        
        <Button
          type="button"
          variant="outline"
          onClick={toggleMode}
          className="flex-shrink-0"
        >
          <Icon name={isUrlMode ? "Search" : "Link"} size={16} className="mr-2" />
          {isUrlMode ? "Search" : "URL"}
        </Button>
        
        <Button
          type="submit"
          variant="default"
          loading={isLoading}
          disabled={!query?.trim()}
          className="flex-shrink-0"
        >
          <Icon name="Plus" size={16} className="mr-2" />
          {isUrlMode ? "Add" : "Search"}
        </Button>
      </form>
      {/* Search Suggestions */}
      {showSuggestions && recentSearches?.length > 0 && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-popover border border-border rounded-lg shadow-elevated z-50">
          <div className="p-2">
            <div className="text-xs font-medium text-muted-foreground mb-2 px-2">Recent Searches</div>
            {recentSearches?.slice(0, 5)?.map((search, index) => (
              <button
                key={index}
                onClick={() => handleSuggestionClick(search)}
                className="flex items-center w-full px-3 py-2 text-sm text-popover-foreground hover:bg-muted rounded transition-smooth"
              >
                <Icon name="Clock" size={14} className="mr-3 text-muted-foreground" />
                <span className="truncate">{search}</span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default SearchBar;
import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const RecentlyAddedPanel = ({ 
  recentVideos = [],
  frequentPlaylists = [],
  onPlaylistClick = () => {},
  onVideoRemove = () => {},
  onClearHistory = () => {}
}) => {
  const [activeTab, setActiveTab] = useState('recent'); // 'recent' or 'playlists'

  const formatDuration = (duration) => {
    if (!duration) return '0:00';
    const minutes = Math.floor(duration / 60);
    const seconds = duration % 60;
    return `${minutes}:${seconds?.toString()?.padStart(2, '0')}`;
  };

  const formatTimeAgo = (timestamp) => {
    const now = new Date();
    const time = new Date(timestamp);
    const diffInMinutes = Math.floor((now - time) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`;
    return `${Math.floor(diffInMinutes / 1440)}d ago`;
  };

  return (
    <div className="bg-card border border-border rounded-lg h-fit sticky top-4">
      {/* Header with Tabs */}
      <div className="border-b border-border">
        <div className="flex items-center">
          <button
            onClick={() => setActiveTab('recent')}
            className={`flex-1 px-4 py-3 text-sm font-medium transition-smooth ${
              activeTab === 'recent' ?'text-primary border-b-2 border-primary' :'text-muted-foreground hover:text-foreground'
            }`}
          >
            <Icon name="Clock" size={16} className="mr-2 inline" />
            Recent
          </button>
          <button
            onClick={() => setActiveTab('playlists')}
            className={`flex-1 px-4 py-3 text-sm font-medium transition-smooth ${
              activeTab === 'playlists' ?'text-primary border-b-2 border-primary' :'text-muted-foreground hover:text-foreground'
            }`}
          >
            <Icon name="List" size={16} className="mr-2 inline" />
            Quick Access
          </button>
        </div>
      </div>
      {/* Content */}
      <div className="p-4">
        {activeTab === 'recent' && (
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-medium text-foreground">Recently Added</h3>
              {recentVideos?.length > 0 && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={onClearHistory}
                  className="text-xs"
                >
                  Clear
                </Button>
              )}
            </div>

            {recentVideos?.length === 0 ? (
              <div className="text-center py-8">
                <Icon name="Clock" size={32} className="text-muted-foreground mx-auto mb-2" />
                <p className="text-sm text-muted-foreground">No recent videos</p>
              </div>
            ) : (
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {recentVideos?.map((video) => (
                  <div key={`${video?.id}-${video?.addedAt}`} className="flex items-start space-x-3 p-2 hover:bg-muted rounded transition-smooth">
                    <div className="relative flex-shrink-0">
                      <div className="w-16 h-12 overflow-hidden rounded">
                        <Image
                          src={video?.thumbnail || `https://img.youtube.com/vi/${video?.id}/maxresdefault.jpg`}
                          alt={video?.title}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="absolute bottom-0 right-0 bg-black bg-opacity-75 text-white text-xs px-1 rounded-tl">
                        {formatDuration(video?.duration)}
                      </div>
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <h4 className="text-xs font-medium text-foreground line-clamp-2 mb-1">
                        {video?.title}
                      </h4>
                      <div className="flex items-center justify-between">
                        <div className="text-xs text-muted-foreground">
                          <div>{video?.playlistName}</div>
                          <div>{formatTimeAgo(video?.addedAt)}</div>
                        </div>
                        <button
                          onClick={() => onVideoRemove(video)}
                          className="p-1 hover:bg-destructive/10 rounded transition-smooth"
                        >
                          <Icon name="X" size={12} className="text-muted-foreground hover:text-destructive" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'playlists' && (
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-medium text-foreground">Frequent Playlists</h3>
              <Icon name="Star" size={16} className="text-accent" />
            </div>

            {frequentPlaylists?.length === 0 ? (
              <div className="text-center py-8">
                <Icon name="List" size={32} className="text-muted-foreground mx-auto mb-2" />
                <p className="text-sm text-muted-foreground">No playlists yet</p>
              </div>
            ) : (
              <div className="space-y-2">
                {frequentPlaylists?.map((playlist) => (
                  <button
                    key={playlist?.id}
                    onClick={() => onPlaylistClick(playlist)}
                    className="flex items-center justify-between w-full p-3 hover:bg-muted rounded-lg transition-smooth text-left"
                  >
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                        <Icon name="List" size={16} className="text-primary" />
                      </div>
                      <div>
                        <div className="text-sm font-medium text-foreground line-clamp-1">
                          {playlist?.name}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {playlist?.videoCount || 0} videos
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="text-xs text-muted-foreground font-mono">
                        {playlist?.recentAdds || 0}
                      </div>
                      <Icon name="ChevronRight" size={14} className="text-muted-foreground" />
                    </div>
                  </button>
                ))}
              </div>
            )}

            <div className="mt-4 pt-4 border-t border-border">
              <Button
                variant="outline"
                fullWidth
                iconName="Plus"
                iconPosition="left"
                onClick={() => window.location.href = '/'}
              >
                Create New Playlist
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default RecentlyAddedPanel;
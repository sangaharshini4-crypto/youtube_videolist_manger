import React, { useState, useRef, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';

const VideoPreviewModal = ({ 
  video = null,
  isOpen = false,
  onClose = () => {},
  onAddToPlaylist = () => {},
  playlists = []
}) => {
  const [selectedPlaylist, setSelectedPlaylist] = useState('');
  const modalRef = useRef(null);

  useEffect(() => {
    const handleEscape = (event) => {
      if (event?.key === 'Escape') {
        onClose();
      }
    };

    const handleClickOutside = (event) => {
      if (modalRef?.current && !modalRef?.current?.contains(event?.target)) {
        onClose();
      }
    };

    if (isOpen) {
      document.addEventListener('keydown', handleEscape);
      document.addEventListener('mousedown', handleClickOutside);
      document.body.style.overflow = 'hidden';
    }

    return () => {
      document.removeEventListener('keydown', handleEscape);
      document.removeEventListener('mousedown', handleClickOutside);
      document.body.style.overflow = 'unset';
    };
  }, [isOpen, onClose]);

  const formatDuration = (duration) => {
    if (!duration) return '0:00';
    const minutes = Math.floor(duration / 60);
    const seconds = duration % 60;
    return `${minutes}:${seconds?.toString()?.padStart(2, '0')}`;
  };

  const formatViewCount = (count) => {
    if (!count) return '0 views';
    if (count >= 1000000) {
      return `${(count / 1000000)?.toFixed(1)}M views`;
    }
    if (count >= 1000) {
      return `${(count / 1000)?.toFixed(1)}K views`;
    }
    return `${count} views`;
  };

  const handleAddToPlaylist = () => {
    if (selectedPlaylist && video) {
      const playlist = playlists?.find(p => p?.id === selectedPlaylist);
      onAddToPlaylist(video, playlist);
      setSelectedPlaylist('');
      onClose();
    }
  };

  const playlistOptions = playlists?.map(playlist => ({
    value: playlist?.id,
    label: playlist?.name,
    description: `${playlist?.videoCount || 0} videos`
  }));

  if (!isOpen || !video) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div
        ref={modalRef}
        className="bg-card border border-border rounded-lg shadow-modal w-full max-w-4xl max-h-[90vh] overflow-hidden animate-fade-in"
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-border">
          <h2 className="text-lg font-semibold text-foreground">Video Preview</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-muted rounded-lg transition-smooth"
          >
            <Icon name="X" size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="flex flex-col lg:flex-row max-h-[calc(90vh-80px)]">
          {/* Video Player Area */}
          <div className="flex-1 bg-black flex items-center justify-center min-h-64 lg:min-h-96">
            <div className="relative w-full h-full">
              <Image
                src={video?.thumbnail || `https://img.youtube.com/vi/${video?.id}/maxresdefault.jpg`}
                alt={video?.title}
                className="w-full h-full object-contain"
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <button
                  onClick={() => window.open(`https://www.youtube.com/watch?v=${video?.id}`, '_blank')}
                  className="w-20 h-20 bg-red-600 hover:bg-red-700 rounded-full flex items-center justify-center transition-colors"
                >
                  <Icon name="Play" size={32} color="white" />
                </button>
              </div>
              <div className="absolute bottom-4 right-4 bg-black bg-opacity-75 text-white text-sm px-3 py-1 rounded">
                {formatDuration(video?.duration)}
              </div>
            </div>
          </div>

          {/* Video Details */}
          <div className="w-full lg:w-96 border-t lg:border-t-0 lg:border-l border-border">
            <div className="p-4 space-y-4 overflow-y-auto max-h-96">
              {/* Title and Channel */}
              <div>
                <h3 className="text-lg font-semibold text-foreground mb-2 line-clamp-2">
                  {video?.title}
                </h3>
                <div className="flex items-center space-x-2 text-sm text-muted-foreground mb-2">
                  <Icon name="User" size={16} />
                  <span>{video?.channelTitle}</span>
                </div>
                <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                  <div className="flex items-center space-x-1">
                    <Icon name="Eye" size={16} />
                    <span>{formatViewCount(video?.viewCount)}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Icon name="Calendar" size={16} />
                    <span>{new Date(video.publishedAt)?.toLocaleDateString()}</span>
                  </div>
                </div>
              </div>

              {/* Description */}
              {video?.description && (
                <div>
                  <h4 className="text-sm font-medium text-foreground mb-2">Description</h4>
                  <p className="text-sm text-muted-foreground line-clamp-6">
                    {video?.description}
                  </p>
                </div>
              )}

              {/* Tags */}
              {video?.tags && video?.tags?.length > 0 && (
                <div>
                  <h4 className="text-sm font-medium text-foreground mb-2">Tags</h4>
                  <div className="flex flex-wrap gap-2">
                    {video?.tags?.slice(0, 8)?.map((tag, index) => (
                      <span
                        key={index}
                        className="px-2 py-1 bg-muted text-xs text-foreground rounded-full"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Add to Playlist Section */}
              <div className="pt-4 border-t border-border">
                <h4 className="text-sm font-medium text-foreground mb-3">Add to Playlist</h4>
                <div className="space-y-3">
                  <Select
                    placeholder="Choose a playlist"
                    options={playlistOptions}
                    value={selectedPlaylist}
                    onChange={setSelectedPlaylist}
                  />
                  <div className="flex space-x-2">
                    <Button
                      variant="default"
                      onClick={handleAddToPlaylist}
                      disabled={!selectedPlaylist}
                      iconName="Plus"
                      iconPosition="left"
                      className="flex-1"
                    >
                      Add to Playlist
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => window.open(`https://www.youtube.com/watch?v=${video?.id}`, '_blank')}
                      iconName="ExternalLink"
                    >
                      Watch
                    </Button>
                  </div>
                </div>
              </div>

              {/* Quick Actions */}
              <div className="pt-4 border-t border-border">
                <h4 className="text-sm font-medium text-foreground mb-3">Quick Actions</h4>
                <div className="grid grid-cols-2 gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    iconName="Share"
                    iconPosition="left"
                    onClick={() => {
                      navigator.clipboard?.writeText(`https://www.youtube.com/watch?v=${video?.id}`);
                      // You could add a toast notification here
                    }}
                  >
                    Share
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    iconName="Download"
                    iconPosition="left"
                    onClick={() => {
                      // Handle download/save functionality
                    }}
                  >
                    Save Info
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VideoPreviewModal;
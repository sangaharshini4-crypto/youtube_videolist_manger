import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';

const SearchFilters = ({ 
  filters = {},
  onFiltersChange = () => {},
  isVisible = false,
  onToggle = () => {}
}) => {
  const [localFilters, setLocalFilters] = useState({
    duration: filters?.duration || '',
    uploadDate: filters?.uploadDate || '',
    sortBy: filters?.sortBy || 'relevance',
    quality: filters?.quality || '',
    ...filters
  });

  const durationOptions = [
    { value: '', label: 'Any Duration' },
    { value: 'short', label: 'Under 4 minutes' },
    { value: 'medium', label: '4-20 minutes' },
    { value: 'long', label: 'Over 20 minutes' }
  ];

  const uploadDateOptions = [
    { value: '', label: 'Any Time' },
    { value: 'hour', label: 'Last Hour' },
    { value: 'today', label: 'Today' },
    { value: 'week', label: 'This Week' },
    { value: 'month', label: 'This Month' },
    { value: 'year', label: 'This Year' }
  ];

  const sortByOptions = [
    { value: 'relevance', label: 'Relevance' },
    { value: 'date', label: 'Upload Date' },
    { value: 'viewCount', label: 'View Count' },
    { value: 'rating', label: 'Rating' },
    { value: 'title', label: 'Title' }
  ];

  const qualityOptions = [
    { value: '', label: 'Any Quality' },
    { value: 'hd', label: 'HD (720p+)' },
    { value: 'hq', label: 'High Quality' }
  ];

  const handleFilterChange = (key, value) => {
    const updatedFilters = {
      ...localFilters,
      [key]: value
    };
    setLocalFilters(updatedFilters);
    onFiltersChange(updatedFilters);
  };

  const clearFilters = () => {
    const clearedFilters = {
      duration: '',
      uploadDate: '',
      sortBy: 'relevance',
      quality: ''
    };
    setLocalFilters(clearedFilters);
    onFiltersChange(clearedFilters);
  };

  const hasActiveFilters = Object.values(localFilters)?.some(value => 
    value && value !== 'relevance'
  );

  return (
    <div className="bg-card border border-border rounded-lg">
      <div className="flex items-center justify-between p-4 border-b border-border">
        <div className="flex items-center space-x-2">
          <Icon name="Filter" size={20} className="text-foreground" />
          <h3 className="text-sm font-medium text-foreground">Search Filters</h3>
          {hasActiveFilters && (
            <div className="w-2 h-2 bg-primary rounded-full"></div>
          )}
        </div>
        <div className="flex items-center space-x-2">
          {hasActiveFilters && (
            <Button
              variant="ghost"
              size="sm"
              onClick={clearFilters}
              className="text-xs"
            >
              Clear All
            </Button>
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={onToggle}
          >
            <Icon name={isVisible ? "ChevronUp" : "ChevronDown"} size={16} />
          </Button>
        </div>
      </div>
      {isVisible && (
        <div className="p-4 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Select
              label="Duration"
              options={durationOptions}
              value={localFilters?.duration}
              onChange={(value) => handleFilterChange('duration', value)}
            />

            <Select
              label="Upload Date"
              options={uploadDateOptions}
              value={localFilters?.uploadDate}
              onChange={(value) => handleFilterChange('uploadDate', value)}
            />

            <Select
              label="Sort By"
              options={sortByOptions}
              value={localFilters?.sortBy}
              onChange={(value) => handleFilterChange('sortBy', value)}
            />

            <Select
              label="Quality"
              options={qualityOptions}
              value={localFilters?.quality}
              onChange={(value) => handleFilterChange('quality', value)}
            />
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-border">
            <div className="text-sm text-muted-foreground">
              {hasActiveFilters ? 'Filters applied' : 'No filters applied'}
            </div>
            <div className="flex space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={clearFilters}
                disabled={!hasActiveFilters}
              >
                Reset
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SearchFilters;
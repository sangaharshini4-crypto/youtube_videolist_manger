import React, { useState, useEffect } from 'react';
import Header from '../../components/ui/Header';
import SearchBar from './components/SearchBar';
import SearchFilters from './components/SearchFilters';
import VideoSearchResults from './components/VideoSearchResults';
import RecentlyAddedPanel from './components/RecentlyAddedPanel';
import VideoPreviewModal from './components/VideoPreviewModal';
import PlaylistQuickActions from '../../components/ui/PlaylistQuickActions';

import Button from '../../components/ui/Button';

const VideoSearchAndAdd = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [filters, setFilters] = useState({});
  const [showFilters, setShowFilters] = useState(false);
  const [selectedVideos, setSelectedVideos] = useState([]);
  const [previewVideo, setPreviewVideo] = useState(null);
  const [showPreview, setShowPreview] = useState(false);
  const [recentSearches, setRecentSearches] = useState([
    "React tutorial",
    "JavaScript basics",
    "CSS animations",
    "Node.js express",
    "MongoDB tutorial"
  ]);

  // Mock data for playlists
  const [playlists] = useState([
    {
      id: '1',
      name: 'Web Development Basics',
      description: 'Fundamental concepts for web development',
      videoCount: 24,
      recentAdds: 5,
      createdAt: new Date('2024-01-15'),
      updatedAt: new Date('2025-01-02')
    },
    {
      id: '2',
      name: 'React Advanced Concepts',
      description: 'Advanced React patterns and techniques',
      videoCount: 18,
      recentAdds: 3,
      createdAt: new Date('2024-02-10'),
      updatedAt: new Date('2025-01-01')
    },
    {
      id: '3',
      name: 'Backend Development',
      description: 'Server-side programming tutorials',
      videoCount: 31,
      recentAdds: 8,
      createdAt: new Date('2024-01-20'),
      updatedAt: new Date('2024-12-30')
    },
    {
      id: '4',
      name: 'UI/UX Design',
      description: 'Design principles and tools',
      videoCount: 15,
      recentAdds: 2,
      createdAt: new Date('2024-03-05'),
      updatedAt: new Date('2024-12-28')
    },
    {
      id: '5',
      name: 'DevOps & Deployment',
      description: 'Deployment and infrastructure tutorials',
      videoCount: 12,
      recentAdds: 1,
      createdAt: new Date('2024-02-25'),
      updatedAt: new Date('2024-12-25')
    }
  ]);

  // Mock data for recently added videos
  const [recentVideos] = useState([
    {
      id: 'dQw4w9WgXcQ',
      title: 'Advanced React Hooks - useCallback and useMemo Explained',
      channelTitle: 'React Mastery',
      duration: 1245,
      thumbnail: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=320&h=180&fit=crop',
      playlistName: 'React Advanced Concepts',
      addedAt: new Date(Date.now() - 300000) // 5 minutes ago
    },
    {
      id: 'abc123def456',
      title: 'CSS Grid Layout Complete Guide',
      channelTitle: 'CSS Tricks',
      duration: 892,
      thumbnail: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=320&h=180&fit=crop',
      playlistName: 'Web Development Basics',
      addedAt: new Date(Date.now() - 1800000) // 30 minutes ago
    },
    {
      id: 'xyz789ghi012',
      title: 'Node.js Express Server Setup Tutorial',
      channelTitle: 'Backend Basics',
      duration: 1567,
      thumbnail: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=320&h=180&fit=crop',
      playlistName: 'Backend Development',
      addedAt: new Date(Date.now() - 3600000) // 1 hour ago
    },
    {
      id: 'mno345pqr678',
      title: 'Figma to React Component Workflow',
      channelTitle: 'Design to Code',
      duration: 734,
      thumbnail: 'https://images.unsplash.com/photo-1581291518857-4e27b48ff24e?w=320&h=180&fit=crop',
      playlistName: 'UI/UX Design',
      addedAt: new Date(Date.now() - 7200000) // 2 hours ago
    }
  ]);

  // Mock search results
  const mockSearchResults = [
    {
      id: 'search1',
      title: 'Complete React Tutorial for Beginners 2025',
      channelTitle: 'Code Academy',
      duration: 3600,
      viewCount: 1250000,
      publishedAt: '2024-12-15T10:00:00Z',
      description: 'Learn React from scratch with this comprehensive tutorial covering components, hooks, state management, and more.',
      thumbnail: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=480&h=270&fit=crop',
      tags: ['react', 'javascript', 'tutorial', 'beginner']
    },
    {
      id: 'search2',
      title: 'Advanced JavaScript ES6+ Features You Must Know',
      channelTitle: 'JS Mastery',
      duration: 2145,
      viewCount: 890000,
      publishedAt: '2024-12-10T14:30:00Z',
      description: 'Explore modern JavaScript features including arrow functions, destructuring, async/await, and more.',
      thumbnail: 'https://images.unsplash.com/photo-1627398242454-45a1465c2479?w=480&h=270&fit=crop',
      tags: ['javascript', 'es6', 'advanced', 'programming']
    },
    {
      id: 'search3',
      title: 'CSS Flexbox and Grid Layout Masterclass',
      channelTitle: 'CSS Pro',
      duration: 1890,
      viewCount: 567000,
      publishedAt: '2024-12-08T09:15:00Z',
      description: 'Master CSS layout with comprehensive coverage of Flexbox and Grid systems.',
      thumbnail: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=480&h=270&fit=crop',
      tags: ['css', 'flexbox', 'grid', 'layout']
    },
    {
      id: 'search4',
      title: 'Node.js and Express.js Full Course',
      channelTitle: 'Backend Dev',
      duration: 4320,
      viewCount: 723000,
      publishedAt: '2024-12-05T16:45:00Z',
      description: 'Build powerful backend applications with Node.js and Express.js from beginner to advanced.',
      thumbnail: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=480&h=270&fit=crop',
      tags: ['nodejs', 'express', 'backend', 'server']
    },
    {
      id: 'search5',
      title: 'MongoDB Database Design and Operations',
      channelTitle: 'Database Expert',
      duration: 2567,
      viewCount: 445000,
      publishedAt: '2024-12-01T11:20:00Z',
      description: 'Learn MongoDB from basics to advanced operations including aggregation, indexing, and performance optimization.',
      thumbnail: 'https://images.unsplash.com/photo-1544383835-bda2bc66a55d?w=480&h=270&fit=crop',
      tags: ['mongodb', 'database', 'nosql', 'operations']
    },
    {
      id: 'search6',
      title: 'React State Management with Redux Toolkit',
      channelTitle: 'State Management Pro',
      duration: 1678,
      viewCount: 334000,
      publishedAt: '2024-11-28T13:10:00Z',
      description: 'Simplify React state management using Redux Toolkit with practical examples and best practices.',
      thumbnail: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=480&h=270&fit=crop',
      tags: ['react', 'redux', 'state-management', 'toolkit']
    }
  ];

  const user = {
    name: 'John Doe',
    email: 'john.doe@example.com'
  };

  const frequentPlaylists = playlists?.sort((a, b) => (b?.recentAdds || 0) - (a?.recentAdds || 0))?.slice(0, 5);

  useEffect(() => {
    document.title = 'Video Search and Add - YouTube Playlist Manager';
  }, []);

  const handleSearch = async (query) => {
    setIsLoading(true);
    setSearchQuery(query);
    
    // Add to recent searches if not already present
    if (!recentSearches?.includes(query)) {
      setRecentSearches(prev => [query, ...prev?.slice(0, 4)]);
    }

    // Simulate API call delay
    setTimeout(() => {
      // Filter mock results based on query
      const filteredResults = mockSearchResults?.filter(video =>
        video?.title?.toLowerCase()?.includes(query?.toLowerCase()) ||
        video?.description?.toLowerCase()?.includes(query?.toLowerCase()) ||
        video?.tags?.some(tag => tag?.toLowerCase()?.includes(query?.toLowerCase()))
      );
      
      setSearchResults(filteredResults);
      setIsLoading(false);
    }, 1500);
  };

  const handleUrlAdd = async (url) => {
    setIsLoading(true);
    
    // Extract video ID from URL (simplified)
    const videoId = url?.includes('youtu.be/') 
      ? url?.split('youtu.be/')?.[1]?.split('?')?.[0]
      : url?.split('v=')?.[1]?.split('&')?.[0];

    // Simulate fetching video data
    setTimeout(() => {
      const mockVideo = {
        id: videoId || 'url-video-1',
        title: 'Video Added from URL',
        channelTitle: 'YouTube Channel',
        duration: 600,
        viewCount: 100000,
        publishedAt: new Date()?.toISOString(),
        description: 'This video was added directly from a YouTube URL.',
        thumbnail: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=480&h=270&fit=crop',
        tags: ['url', 'direct-add']
      };
      
      setSearchResults([mockVideo]);
      setIsLoading(false);
    }, 1000);
  };

  const handleFiltersChange = (newFilters) => {
    setFilters(newFilters);
    // In a real app, this would trigger a new search with filters
    console.log('Filters updated:', newFilters);
  };

  const handleVideoSelect = (videoId, isSelected) => {
    if (isSelected) {
      setSelectedVideos(prev => [...prev, videoId]);
    } else {
      setSelectedVideos(prev => prev?.filter(id => id !== videoId));
    }
  };

  const handleAddToPlaylist = (video, playlist) => {
    console.log(`Adding video "${video?.title}" to playlist "${playlist?.name}"`);
    // In a real app, this would make an API call
    
    // Show success feedback
    alert(`Video added to "${playlist?.name}" successfully!`);
    
    // Remove from selected videos if it was selected
    setSelectedVideos(prev => prev?.filter(id => id !== video?.id));
  };

  const handleBulkAdd = (videoIds, playlist) => {
    console.log(`Adding ${videoIds?.length} videos to playlist "${playlist?.name}"`);
    // In a real app, this would make an API call
    
    // Show success feedback
    alert(`${videoIds?.length} videos added to "${playlist?.name}" successfully!`);
    
    // Clear selected videos
    setSelectedVideos([]);
  };

  const handlePreview = (video) => {
    setPreviewVideo(video);
    setShowPreview(true);
  };

  const handlePlaylistClick = (playlist) => {
    // Navigate to playlist or show playlist details
    console.log('Playlist clicked:', playlist?.name);
    window.location.href = `/playlist/${playlist?.id}`;
  };

  const handleVideoRemove = (video) => {
    console.log('Remove video from recent:', video?.title);
    // In a real app, this would update the recent videos list
  };

  const handleClearHistory = () => {
    console.log('Clear recent videos history');
    // In a real app, this would clear the recent videos
  };

  const handleCreatePlaylist = (playlistData) => {
    console.log('Create new playlist:', playlistData);
    // In a real app, this would create a new playlist
    alert(`Playlist "${playlistData?.name}" created successfully!`);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header isAuthenticated={true} user={user} />
      <div className="pt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          {/* Page Header */}
          <div className="mb-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-semibold text-foreground mb-2">
                  Video Search & Add
                </h1>
                <p className="text-muted-foreground">
                  Discover and add YouTube videos to your playlists
                </p>
              </div>
              <div className="flex items-center space-x-3">
                <Button
                  variant="outline"
                  onClick={() => window.location.href = '/'}
                  iconName="ArrowLeft"
                  iconPosition="left"
                >
                  Back to Playlists
                </Button>
                <Button
                  variant="default"
                  onClick={() => window.location.href = '/video-player'}
                  iconName="Play"
                  iconPosition="left"
                >
                  Open Player
                </Button>
              </div>
            </div>
          </div>

          {/* Search Section */}
          <div className="mb-6">
            <SearchBar
              onSearch={handleSearch}
              onUrlAdd={handleUrlAdd}
              searchQuery={searchQuery}
              isLoading={isLoading}
              recentSearches={recentSearches}
            />
          </div>

          {/* Filters */}
          <div className="mb-6">
            <SearchFilters
              filters={filters}
              onFiltersChange={handleFiltersChange}
              isVisible={showFilters}
              onToggle={() => setShowFilters(!showFilters)}
            />
          </div>

          {/* Main Content */}
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Search Results */}
            <div className="lg:col-span-3">
              <VideoSearchResults
                videos={searchResults}
                isLoading={isLoading}
                onAddToPlaylist={handleAddToPlaylist}
                onBulkAdd={handleBulkAdd}
                playlists={playlists}
                selectedVideos={selectedVideos}
                onVideoSelect={handleVideoSelect}
                onPreview={handlePreview}
              />
            </div>

            {/* Sidebar */}
            <div className="lg:col-span-1">
              <RecentlyAddedPanel
                recentVideos={recentVideos}
                frequentPlaylists={frequentPlaylists}
                onPlaylistClick={handlePlaylistClick}
                onVideoRemove={handleVideoRemove}
                onClearHistory={handleClearHistory}
              />
            </div>
          </div>
        </div>
      </div>
      {/* Quick Actions */}
      <PlaylistQuickActions
        isVisible={selectedVideos?.length > 0}
        position="floating"
        recentPlaylists={frequentPlaylists}
        onCreatePlaylist={handleCreatePlaylist}
        onQuickAdd={handleBulkAdd}
        selectedVideos={selectedVideos}
      />
      {/* Video Preview Modal */}
      <VideoPreviewModal
        video={previewVideo}
        isOpen={showPreview}
        onClose={() => setShowPreview(false)}
        onAddToPlaylist={handleAddToPlaylist}
        playlists={playlists}
      />
    </div>
  );
};

export default VideoSearchAndAdd;
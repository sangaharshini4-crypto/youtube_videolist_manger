import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';


const VideoMetadata = ({ 
  video = null,
  userNotes = '',
  onNotesChange = () => {},
  onAddToPlaylist = () => {},
  onMarkFavorite = () => {},
  onShare = () => {},
  isFavorite = false,
  playlists = []
}) => {
  const [isEditingNotes, setIsEditingNotes] = useState(false);
  const [tempNotes, setTempNotes] = useState(userNotes);
  const [showPlaylistMenu, setShowPlaylistMenu] = useState(false);

  const handleSaveNotes = () => {
    onNotesChange(tempNotes);
    setIsEditingNotes(false);
  };

  const handleCancelNotes = () => {
    setTempNotes(userNotes);
    setIsEditingNotes(false);
  };

  if (!video) {
    return (
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="text-center text-muted-foreground">
          <Icon name="FileText" size={32} className="mx-auto mb-2" />
          <p>Select a video to view details</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card border border-border rounded-lg">
      {/* Video Header */}
      <div className="p-6 border-b border-border">
        <div className="flex items-start justify-between">
          <div className="flex-1 min-w-0">
            <h1 className="text-xl font-semibold text-foreground mb-2 line-clamp-2">
              {video?.title}
            </h1>
            <div className="flex items-center space-x-4 text-sm text-muted-foreground">
              <div className="flex items-center space-x-1">
                <Icon name="User" size={16} />
                <span>{video?.channelName}</span>
              </div>
              <div className="flex items-center space-x-1">
                <Icon name="Eye" size={16} />
                <span>{video?.views} views</span>
              </div>
              <div className="flex items-center space-x-1">
                <Icon name="Calendar" size={16} />
                <span>{video?.publishedAt}</span>
              </div>
              <div className="flex items-center space-x-1">
                <Icon name="Clock" size={16} />
                <span>{video?.duration}</span>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center space-x-2 ml-4">
            <Button
              variant={isFavorite ? "default" : "outline"}
              size="sm"
              onClick={onMarkFavorite}
              iconName="Heart"
              iconPosition="left"
            >
              {isFavorite ? 'Favorited' : 'Favorite'}
            </Button>

            <div className="relative">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowPlaylistMenu(!showPlaylistMenu)}
                iconName="Plus"
                iconPosition="left"
              >
                Add to Playlist
              </Button>

              {showPlaylistMenu && (
                <div className="absolute top-full right-0 mt-2 w-64 bg-popover border border-border rounded-lg shadow-elevated z-10">
                  <div className="p-2">
                    <div className="text-sm font-medium text-foreground mb-2 px-2">
                      Add to Playlist
                    </div>
                    <div className="max-h-48 overflow-y-auto space-y-1">
                      {playlists?.map((playlist) => (
                        <button
                          key={playlist?.id}
                          onClick={() => {
                            onAddToPlaylist(playlist);
                            setShowPlaylistMenu(false);
                          }}
                          className="flex items-center justify-between w-full p-2 text-sm text-foreground hover:bg-muted rounded transition-smooth"
                        >
                          <div className="flex items-center space-x-2">
                            <Icon name="List" size={14} />
                            <span className="truncate">{playlist?.name}</span>
                          </div>
                          <span className="text-xs text-muted-foreground font-mono">
                            {playlist?.videoCount}
                          </span>
                        </button>
                      ))}
                    </div>
                    <div className="border-t border-border mt-2 pt-2">
                      <button className="flex items-center space-x-2 w-full p-2 text-sm text-primary hover:bg-muted rounded transition-smooth">
                        <Icon name="PlusCircle" size={14} />
                        <span>Create New Playlist</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>

            <Button
              variant="outline"
              size="sm"
              onClick={onShare}
              iconName="Share"
              iconPosition="left"
            >
              Share
            </Button>
          </div>
        </div>
      </div>
      {/* Video Description */}
      <div className="p-6 border-b border-border">
        <h3 className="text-sm font-medium text-foreground mb-3">Description</h3>
        <div className="text-sm text-muted-foreground whitespace-pre-wrap">
          {video?.description || 'No description available.'}
        </div>
      </div>
      {/* User Notes */}
      <div className="p-6">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-medium text-foreground">My Notes</h3>
          {!isEditingNotes && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsEditingNotes(true)}
              iconName="Edit"
              iconPosition="left"
            >
              Edit
            </Button>
          )}
        </div>

        {isEditingNotes ? (
          <div className="space-y-3">
            <textarea
              value={tempNotes}
              onChange={(e) => setTempNotes(e?.target?.value)}
              placeholder="Add your notes about this video..."
              className="w-full h-32 p-3 text-sm bg-muted border border-border rounded-md focus:outline-none focus:ring-2 focus:ring-ring resize-none"
            />
            <div className="flex justify-end space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={handleCancelNotes}
              >
                Cancel
              </Button>
              <Button
                variant="default"
                size="sm"
                onClick={handleSaveNotes}
                iconName="Save"
                iconPosition="left"
              >
                Save Notes
              </Button>
            </div>
          </div>
        ) : (
          <div className="text-sm text-muted-foreground">
            {userNotes || (
              <div className="flex items-center space-x-2 text-muted-foreground/60">
                <Icon name="FileText" size={16} />
                <span>No notes added yet. Click Edit to add your thoughts.</span>
              </div>
            )}
          </div>
        )}
      </div>
      {/* Video Tags */}
      {video?.tags && video?.tags?.length > 0 && (
        <div className="px-6 pb-6">
          <h3 className="text-sm font-medium text-foreground mb-3">Tags</h3>
          <div className="flex flex-wrap gap-2">
            {video?.tags?.map((tag, index) => (
              <span
                key={index}
                className="px-2 py-1 bg-muted text-xs text-foreground rounded-md"
              >
                #{tag}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default VideoMetadata;
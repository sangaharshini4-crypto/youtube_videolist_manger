import React, { useState, useRef, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const VideoPlayerMain = ({ 
  currentVideo = null,
  isPlaying = false,
  onPlayPause = () => {},
  onNext = () => {},
  onPrevious = () => {},
  onVolumeChange = () => {},
  onSeek = () => {},
  onFullscreen = () => {},
  volume = 100,
  currentTime = 0,
  duration = 0,
  isFullscreen = false
}) => {
  const [showControls, setShowControls] = useState(true);
  const [isHovering, setIsHovering] = useState(false);
  const controlsTimeoutRef = useRef(null);

  useEffect(() => {
    if (isPlaying && !isHovering) {
      controlsTimeoutRef.current = setTimeout(() => {
        setShowControls(false);
      }, 3000);
    } else {
      setShowControls(true);
    }

    return () => {
      if (controlsTimeoutRef?.current) {
        clearTimeout(controlsTimeoutRef?.current);
      }
    };
  }, [isPlaying, isHovering]);

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs?.toString()?.padStart(2, '0')}`;
  };

  const handleMouseMove = () => {
    setShowControls(true);
    if (controlsTimeoutRef?.current) {
      clearTimeout(controlsTimeoutRef?.current);
    }
  };

  if (!currentVideo) {
    return (
      <div className="w-full h-full bg-muted rounded-lg flex items-center justify-center">
        <div className="text-center">
          <Icon name="Play" size={64} className="text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-medium text-foreground mb-2">No Video Selected</h3>
          <p className="text-muted-foreground">Choose a video from your playlist to start watching</p>
        </div>
      </div>
    );
  }

  return (
    <div 
      className={`relative w-full h-full bg-black rounded-lg overflow-hidden ${isFullscreen ? 'fixed inset-0 z-50 rounded-none' : ''}`}
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setIsHovering(true)}
      onMouseLeave={() => setIsHovering(false)}
    >
      {/* YouTube Embed */}
      <iframe
        src={`https://www.youtube.com/embed/${currentVideo?.videoId}?autoplay=${isPlaying ? 1 : 0}&controls=0&modestbranding=1&rel=0`}
        title={currentVideo?.title}
        className="w-full h-full"
        frameBorder="0"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
        allowFullScreen
      />
      {/* Custom Controls Overlay */}
      <div className={`absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent transition-opacity duration-300 ${showControls ? 'opacity-100' : 'opacity-0'}`}>
        {/* Top Controls */}
        <div className="absolute top-0 left-0 right-0 p-4 bg-gradient-to-b from-black/60 to-transparent">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <h2 className="text-white font-medium text-lg truncate max-w-md">
                {currentVideo?.title}
              </h2>
              <div className="text-white/80 text-sm font-mono">
                {currentVideo?.duration}
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Button
                variant="ghost"
                size="icon"
                onClick={onFullscreen}
                className="text-white hover:bg-white/20"
              >
                <Icon name={isFullscreen ? "Minimize" : "Maximize"} size={20} />
              </Button>
            </div>
          </div>
        </div>

        {/* Center Play/Pause Button */}
        <div className="absolute inset-0 flex items-center justify-center">
          <Button
            variant="ghost"
            size="icon"
            onClick={onPlayPause}
            className="w-16 h-16 bg-black/40 hover:bg-black/60 text-white rounded-full"
          >
            <Icon name={isPlaying ? "Pause" : "Play"} size={32} />
          </Button>
        </div>

        {/* Bottom Controls */}
        <div className="absolute bottom-0 left-0 right-0 p-4">
          {/* Progress Bar */}
          <div className="mb-4">
            <div className="relative">
              <div className="w-full h-1 bg-white/30 rounded-full">
                <div 
                  className="h-full bg-primary rounded-full transition-all duration-200"
                  style={{ width: `${duration > 0 ? (currentTime / duration) * 100 : 0}%` }}
                />
              </div>
              <input
                type="range"
                min="0"
                max={duration}
                value={currentTime}
                onChange={(e) => onSeek(parseInt(e?.target?.value))}
                className="absolute inset-0 w-full h-1 opacity-0 cursor-pointer"
              />
            </div>
            <div className="flex justify-between text-white/80 text-sm font-mono mt-1">
              <span>{formatTime(currentTime)}</span>
              <span>{formatTime(duration)}</span>
            </div>
          </div>

          {/* Control Buttons */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Button
                variant="ghost"
                size="icon"
                onClick={onPrevious}
                className="text-white hover:bg-white/20"
              >
                <Icon name="SkipBack" size={20} />
              </Button>
              
              <Button
                variant="ghost"
                size="icon"
                onClick={onPlayPause}
                className="text-white hover:bg-white/20"
              >
                <Icon name={isPlaying ? "Pause" : "Play"} size={20} />
              </Button>
              
              <Button
                variant="ghost"
                size="icon"
                onClick={onNext}
                className="text-white hover:bg-white/20"
              >
                <Icon name="SkipForward" size={20} />
              </Button>
            </div>

            {/* Volume Control */}
            <div className="flex items-center space-x-2">
              <Button
                variant="ghost"
                size="icon"
                className="text-white hover:bg-white/20"
              >
                <Icon name={volume === 0 ? "VolumeX" : volume < 50 ? "Volume1" : "Volume2"} size={20} />
              </Button>
              <input
                type="range"
                min="0"
                max="100"
                value={volume}
                onChange={(e) => onVolumeChange(parseInt(e?.target?.value))}
                className="w-20 h-1 bg-white/30 rounded-full appearance-none slider"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VideoPlayerMain;
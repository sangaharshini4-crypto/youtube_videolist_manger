import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const PlayerControls = ({ 
  onPrevious = () => {},
  onNext = () => {},
  onShuffle = () => {},
  onRepeat = () => {},
  onPlaybackSpeed = () => {},
  onQuality = () => {},
  isShuffled = false,
  repeatMode = 'none', // 'none', 'all', 'one'
  playbackSpeed = 1,
  quality = 'auto',
  canGoPrevious = true,
  canGoNext = true
}) => {
  const [showSpeedMenu, setShowSpeedMenu] = useState(false);
  const [showQualityMenu, setShowQualityMenu] = useState(false);

  const speedOptions = [0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2];
  const qualityOptions = ['auto', '144p', '240p', '360p', '480p', '720p', '1080p'];

  const getRepeatIcon = () => {
    switch (repeatMode) {
      case 'all':
        return 'Repeat';
      case 'one':
        return 'Repeat1';
      default:
        return 'Repeat';
    }
  };

  const getRepeatColor = () => {
    return repeatMode !== 'none' ? 'text-primary' : 'text-muted-foreground';
  };

  return (
    <div className="bg-card border border-border rounded-lg p-4">
      <div className="flex items-center justify-between">
        {/* Navigation Controls */}
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            size="sm"
            onClick={onPrevious}
            disabled={!canGoPrevious}
            iconName="SkipBack"
            iconPosition="left"
          >
            Previous
          </Button>

          <Button
            variant="outline"
            size="sm"
            onClick={onNext}
            disabled={!canGoNext}
            iconName="SkipForward"
            iconPosition="left"
          >
            Next
          </Button>
        </div>

        {/* Playback Controls */}
        <div className="flex items-center space-x-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={onShuffle}
            className={isShuffled ? 'text-primary' : 'text-muted-foreground'}
          >
            <Icon name="Shuffle" size={16} className="mr-1" />
            Shuffle
          </Button>

          <Button
            variant="ghost"
            size="sm"
            onClick={onRepeat}
            className={getRepeatColor()}
          >
            <Icon name={getRepeatIcon()} size={16} className="mr-1" />
            Repeat
          </Button>

          {/* Playback Speed */}
          <div className="relative">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowSpeedMenu(!showSpeedMenu)}
            >
              <Icon name="Gauge" size={16} className="mr-1" />
              {playbackSpeed}x
            </Button>

            {showSpeedMenu && (
              <div className="absolute bottom-full mb-2 left-0 bg-popover border border-border rounded-lg shadow-elevated z-10">
                <div className="p-2 min-w-24">
                  <div className="text-xs font-medium text-foreground mb-2 px-2">
                    Playback Speed
                  </div>
                  {speedOptions?.map((speed) => (
                    <button
                      key={speed}
                      onClick={() => {
                        onPlaybackSpeed(speed);
                        setShowSpeedMenu(false);
                      }}
                      className={`block w-full text-left px-2 py-1 text-sm rounded transition-smooth ${
                        speed === playbackSpeed 
                          ? 'bg-primary text-primary-foreground' 
                          : 'text-foreground hover:bg-muted'
                      }`}
                    >
                      {speed}x
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Quality */}
          <div className="relative">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowQualityMenu(!showQualityMenu)}
            >
              <Icon name="Settings" size={16} className="mr-1" />
              {quality}
            </Button>

            {showQualityMenu && (
              <div className="absolute bottom-full mb-2 right-0 bg-popover border border-border rounded-lg shadow-elevated z-10">
                <div className="p-2 min-w-20">
                  <div className="text-xs font-medium text-foreground mb-2 px-2">
                    Quality
                  </div>
                  {qualityOptions?.map((qual) => (
                    <button
                      key={qual}
                      onClick={() => {
                        onQuality(qual);
                        setShowQualityMenu(false);
                      }}
                      className={`block w-full text-left px-2 py-1 text-sm rounded transition-smooth ${
                        qual === quality 
                          ? 'bg-primary text-primary-foreground' 
                          : 'text-foreground hover:bg-muted'
                      }`}
                    >
                      {qual}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Additional Actions */}
        <div className="flex items-center space-x-2">
          <Button
            variant="ghost"
            size="sm"
          >
            <Icon name="Download" size={16} className="mr-1" />
            Download
          </Button>

          <Button
            variant="ghost"
            size="sm"
          >
            <Icon name="ExternalLink" size={16} className="mr-1" />
            YouTube
          </Button>
        </div>
      </div>
    </div>
  );
};

export default PlayerControls;
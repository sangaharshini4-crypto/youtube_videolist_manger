import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const PlaylistSidebar = ({ 
  playlist = null,
  videos = [],
  currentVideoIndex = 0,
  onVideoSelect = () => {},
  onShuffle = () => {},
  onRepeat = () => {},
  isShuffled = false,
  repeatMode = 'none', // 'none', 'all', 'one'
  isCollapsed = false,
  onToggleCollapse = () => {}
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredVideos = videos?.filter(video =>
    video?.title?.toLowerCase()?.includes(searchQuery?.toLowerCase()) ||
    video?.description?.toLowerCase()?.includes(searchQuery?.toLowerCase())
  );

  const getRepeatIcon = () => {
    switch (repeatMode) {
      case 'all':
        return 'Repeat';
      case 'one':
        return 'Repeat1';
      default:
        return 'Repeat';
    }
  };

  const getRepeatColor = () => {
    return repeatMode !== 'none' ? 'text-primary' : 'text-muted-foreground';
  };

  if (isCollapsed) {
    return (
      <div className="w-12 bg-card border-l border-border h-full flex flex-col items-center py-4 space-y-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={onToggleCollapse}
          className="text-muted-foreground hover:text-foreground"
        >
          <Icon name="ChevronLeft" size={20} />
        </Button>
        <div className="text-xs text-muted-foreground transform -rotate-90 whitespace-nowrap">
          {videos?.length} videos
        </div>
      </div>
    );
  }

  return (
    <div className="w-80 bg-card border-l border-border h-full flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-2">
            <Icon name="List" size={20} className="text-primary" />
            <h3 className="font-medium text-foreground">
              {playlist?.name || 'Current Playlist'}
            </h3>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={onToggleCollapse}
            className="text-muted-foreground hover:text-foreground"
          >
            <Icon name="ChevronRight" size={20} />
          </Button>
        </div>

        {/* Playlist Controls */}
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={onShuffle}
              className={isShuffled ? 'text-primary' : 'text-muted-foreground'}
            >
              <Icon name="Shuffle" size={16} className="mr-1" />
              Shuffle
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={onRepeat}
              className={getRepeatColor()}
            >
              <Icon name={getRepeatIcon()} size={16} className="mr-1" />
              Repeat
            </Button>
          </div>
          
          <div className="text-sm text-muted-foreground font-mono">
            {currentVideoIndex + 1}/{videos?.length}
          </div>
        </div>

        {/* Search */}
        <div className="relative">
          <Icon name="Search" size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search in playlist..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e?.target?.value)}
            className="w-full pl-9 pr-3 py-2 text-sm bg-muted border border-border rounded-md focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>
      </div>
      {/* Video List */}
      <div className="flex-1 overflow-y-auto">
        {filteredVideos?.length === 0 ? (
          <div className="p-4 text-center">
            <Icon name="Search" size={32} className="text-muted-foreground mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">
              {searchQuery ? 'No videos found' : 'No videos in playlist'}
            </p>
          </div>
        ) : (
          <div className="space-y-1 p-2">
            {filteredVideos?.map((video, index) => {
              const originalIndex = videos?.findIndex(v => v?.id === video?.id);
              const isCurrentVideo = originalIndex === currentVideoIndex;
              
              return (
                <div
                  key={video?.id}
                  onClick={() => onVideoSelect(originalIndex)}
                  className={`flex items-start space-x-3 p-2 rounded-md cursor-pointer transition-smooth ${
                    isCurrentVideo 
                      ? 'bg-primary/10 border border-primary/20' :'hover:bg-muted'
                  }`}
                >
                  {/* Thumbnail */}
                  <div className="relative flex-shrink-0">
                    <Image
                      src={video?.thumbnail}
                      alt={video?.title}
                      className="w-16 h-12 object-cover rounded"
                    />
                    <div className="absolute bottom-1 right-1 bg-black/80 text-white text-xs px-1 rounded font-mono">
                      {video?.duration}
                    </div>
                    {isCurrentVideo && (
                      <div className="absolute inset-0 bg-primary/20 rounded flex items-center justify-center">
                        <Icon name="Play" size={16} className="text-primary" />
                      </div>
                    )}
                  </div>
                  {/* Video Info */}
                  <div className="flex-1 min-w-0">
                    <h4 className={`text-sm font-medium line-clamp-2 ${
                      isCurrentVideo ? 'text-primary' : 'text-foreground'
                    }`}>
                      {video?.title}
                    </h4>
                    <p className="text-xs text-muted-foreground mt-1">
                      {video?.channelName}
                    </p>
                    <div className="flex items-center space-x-2 mt-1">
                      <span className="text-xs text-muted-foreground">
                        {video?.views} views
                      </span>
                      <span className="text-xs text-muted-foreground">•</span>
                      <span className="text-xs text-muted-foreground">
                        {video?.publishedAt}
                      </span>
                    </div>
                    {video?.watchProgress > 0 && (
                      <div className="mt-2">
                        <div className="w-full h-1 bg-muted rounded-full">
                          <div 
                            className="h-full bg-primary rounded-full"
                            style={{ width: `${video?.watchProgress}%` }}
                          />
                        </div>
                      </div>
                    )}
                  </div>
                  {/* Index Number */}
                  <div className="flex-shrink-0 text-xs text-muted-foreground font-mono w-6 text-right">
                    {originalIndex + 1}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
      {/* Footer Stats */}
      <div className="p-4 border-t border-border bg-muted/30">
        <div className="flex items-center justify-between text-sm">
          <div className="text-muted-foreground">
            Total: {videos?.length} videos
          </div>
          <div className="text-muted-foreground font-mono">
            {playlist?.totalDuration || '0:00'}
          </div>
        </div>
        {playlist?.description && (
          <p className="text-xs text-muted-foreground mt-2 line-clamp-2">
            {playlist?.description}
          </p>
        )}
      </div>
    </div>
  );
};

export default PlaylistSidebar;
import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import Header from '../../components/ui/Header';
import VideoPlayerMain from './components/VideoPlayerMain';
import PlaylistSidebar from './components/PlaylistSidebar';
import VideoMetadata from './components/VideoMetadata';
import PlayerControls from './components/PlayerControls';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const VideoPlayerPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  
  // Mock user data
  const [user] = useState({
    name: "Alex Johnson",
    email: "alex.johnson@example.com"
  });

  // Player state
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentVideoIndex, setCurrentVideoIndex] = useState(0);
  const [volume, setVolume] = useState(100);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isShuffled, setIsShuffled] = useState(false);
  const [repeatMode, setRepeatMode] = useState('none');
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const [quality, setQuality] = useState('auto');
  const [userNotes, setUserNotes] = useState('');

  // Mock playlist data
  const [currentPlaylist] = useState({
    id: 'pl-1',
    name: 'React Development Tutorials',
    description: 'Comprehensive collection of React.js tutorials and best practices for modern web development',
    totalDuration: '4:32:15',
    videoCount: 12,
    createdAt: '2025-01-15',
    updatedAt: '2025-01-20'
  });

  // Mock videos data
  const [videos] = useState([
    {
      id: 'v-1',
      videoId: 'dQw4w9WgXcQ',
      title: 'React Hooks Complete Guide - useState, useEffect, and Custom Hooks',
      description: `Learn everything about React Hooks in this comprehensive tutorial. We'll cover:\n\n• useState for state management\n• useEffect for side effects\n• Custom hooks for reusable logic\n• Best practices and common patterns\n\nThis tutorial is perfect for developers who want to master modern React development techniques.`,
      thumbnail: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=320&h=180&fit=crop',
      duration: '24:35',
      channelName: 'React Mastery',
      views: '125,432',
      publishedAt: '2 days ago',
      watchProgress: 65,
      tags: ['react', 'hooks', 'javascript', 'frontend']
    },
    {
      id: 'v-2',
      videoId: 'dQw4w9WgXcQ',
      title: 'Building Responsive Layouts with CSS Grid and Flexbox',
      description: `Master modern CSS layout techniques with this hands-on tutorial covering CSS Grid and Flexbox.\n\nTopics covered:\n• CSS Grid fundamentals\n• Flexbox properties\n• Responsive design patterns\n• Real-world examples`,
      thumbnail: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=320&h=180&fit=crop',
      duration: '18:42',
      channelName: 'CSS Wizardry',
      views: '89,234',
      publishedAt: '5 days ago',
      watchProgress: 0,
      tags: ['css', 'grid', 'flexbox', 'responsive']
    },
    {
      id: 'v-3',
      videoId: 'dQw4w9WgXcQ',
      title: 'JavaScript ES6+ Features Every Developer Should Know',
      description: `Explore the latest JavaScript features that will make your code more efficient and readable.\n\nFeatures covered:\n• Arrow functions\n• Destructuring\n• Template literals\n• Async/await\n• Modules`,
      thumbnail: 'https://images.unsplash.com/photo-1579468118864-1b9ea3c0db4a?w=320&h=180&fit=crop',
      duration: '31:28',
      channelName: 'Modern JavaScript',
      views: '203,567',
      publishedAt: '1 week ago',
      watchProgress: 100,
      tags: ['javascript', 'es6', 'modern', 'features']
    },
    {
      id: 'v-4',
      videoId: 'dQw4w9WgXcQ',
      title: 'State Management with Redux Toolkit',
      description: `Learn how to manage complex application state using Redux Toolkit, the modern way to use Redux.\n\nWhat you'll learn:\n• Redux Toolkit setup\n• Creating slices\n• Async thunks\n• Best practices`,
      thumbnail: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=320&h=180&fit=crop',
      duration: '42:15',
      channelName: 'State Management Pro',
      views: '67,890',
      publishedAt: '2 weeks ago',
      watchProgress: 25,
      tags: ['redux', 'state-management', 'react', 'toolkit']
    },
    {
      id: 'v-5',
      videoId: 'dQw4w9WgXcQ',
      title: 'TypeScript for React Developers',
      description: `Add type safety to your React applications with TypeScript. Perfect for developers transitioning from JavaScript.\n\nCovering:\n• TypeScript basics\n• React component typing\n• Props and state types\n• Common patterns`,
      thumbnail: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=320&h=180&fit=crop',
      duration: '36:52',
      channelName: 'TypeScript Tutorials',
      views: '145,678',
      publishedAt: '3 weeks ago',
      watchProgress: 0,
      tags: ['typescript', 'react', 'types', 'javascript']
    }
  ]);

  // Mock playlists for adding videos
  const [availablePlaylists] = useState([
    { id: 'pl-2', name: 'JavaScript Fundamentals', videoCount: 8 },
    { id: 'pl-3', name: 'CSS Mastery', videoCount: 15 },
    { id: 'pl-4', name: 'Web Development Tools', videoCount: 6 },
    { id: 'pl-5', name: 'Frontend Frameworks', videoCount: 12 }
  ]);

  const currentVideo = videos?.[currentVideoIndex];

  // Simulate video progress
  useEffect(() => {
    let interval;
    if (isPlaying && currentVideo) {
      interval = setInterval(() => {
        setCurrentTime(prev => {
          const newTime = prev + 1;
          const videoDuration = parseInt(currentVideo?.duration?.split(':')?.[0]) * 60 + parseInt(currentVideo?.duration?.split(':')?.[1]);
          setDuration(videoDuration);
          
          if (newTime >= videoDuration) {
            handleNext();
            return 0;
          }
          return newTime;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isPlaying, currentVideo]);

  // Get video notes
  useEffect(() => {
    // Simulate loading user notes for current video
    const mockNotes = {
      'v-1': 'Great explanation of hooks! Need to practice custom hooks more.',
      'v-3': 'Excellent overview of ES6 features. Bookmarked for reference.',
      'v-4': 'Redux Toolkit makes state management much simpler than traditional Redux.'
    };
    setUserNotes(mockNotes?.[currentVideo?.id] || '');
  }, [currentVideo]);

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const handleNext = () => {
    if (repeatMode === 'one') {
      setCurrentTime(0);
      return;
    }
    
    let nextIndex;
    if (isShuffled) {
      nextIndex = Math.floor(Math.random() * videos?.length);
    } else {
      nextIndex = currentVideoIndex + 1;
      if (nextIndex >= videos?.length) {
        if (repeatMode === 'all') {
          nextIndex = 0;
        } else {
          setIsPlaying(false);
          return;
        }
      }
    }
    setCurrentVideoIndex(nextIndex);
    setCurrentTime(0);
  };

  const handlePrevious = () => {
    if (currentTime > 10) {
      setCurrentTime(0);
      return;
    }
    
    let prevIndex;
    if (isShuffled) {
      prevIndex = Math.floor(Math.random() * videos?.length);
    } else {
      prevIndex = currentVideoIndex - 1;
      if (prevIndex < 0) {
        if (repeatMode === 'all') {
          prevIndex = videos?.length - 1;
        } else {
          prevIndex = 0;
        }
      }
    }
    setCurrentVideoIndex(prevIndex);
    setCurrentTime(0);
  };

  const handleVideoSelect = (index) => {
    setCurrentVideoIndex(index);
    setCurrentTime(0);
    setIsPlaying(true);
  };

  const handleVolumeChange = (newVolume) => {
    setVolume(newVolume);
  };

  const handleSeek = (time) => {
    setCurrentTime(time);
  };

  const handleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
  };

  const handleShuffle = () => {
    setIsShuffled(!isShuffled);
  };

  const handleRepeat = () => {
    const modes = ['none', 'all', 'one'];
    const currentIndex = modes?.indexOf(repeatMode);
    let nextIndex = (currentIndex + 1) % modes?.length;
    setRepeatMode(modes?.[nextIndex]);
  };

  const handleNotesChange = (notes) => {
    setUserNotes(notes);
    // Here you would typically save to backend
    console.log('Saving notes for video:', currentVideo?.id, notes);
  };

  const handleAddToPlaylist = (playlist) => {
    console.log('Adding video to playlist:', currentVideo?.id, playlist?.id);
    // Here you would typically make API call
  };

  const handleMarkFavorite = () => {
    console.log('Toggling favorite for video:', currentVideo?.id);
    // Here you would typically make API call
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: currentVideo?.title,
        text: `Check out this video: ${currentVideo?.title}`,
        url: window.location?.href
      });
    } else {
      navigator.clipboard?.writeText(window.location?.href);
      alert('Link copied to clipboard!');
    }
  };

  const handleLogout = () => {
    navigate('/login');
  };

  return (
    <div className="min-h-screen bg-background">
      <Header 
        isAuthenticated={true}
        user={user}
        onLogout={handleLogout}
      />
      <div className="pt-16">
        {/* Mobile Header */}
        <div className="lg:hidden bg-card border-b border-border p-4">
          <div className="flex items-center justify-between">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate('/')}
              iconName="ArrowLeft"
              iconPosition="left"
            >
              Back to Playlists
            </Button>
            <div className="text-sm text-muted-foreground font-mono">
              {currentVideoIndex + 1} / {videos?.length}
            </div>
          </div>
        </div>

        <div className="flex h-[calc(100vh-4rem)]">
          {/* Main Content */}
          <div className="flex-1 flex flex-col min-w-0">
            {/* Video Player */}
            <div className="flex-1 p-4 lg:p-6">
              <div className="h-full max-w-6xl mx-auto">
                <VideoPlayerMain
                  currentVideo={currentVideo}
                  isPlaying={isPlaying}
                  onPlayPause={handlePlayPause}
                  onNext={handleNext}
                  onPrevious={handlePrevious}
                  onVolumeChange={handleVolumeChange}
                  onSeek={handleSeek}
                  onFullscreen={handleFullscreen}
                  volume={volume}
                  currentTime={currentTime}
                  duration={duration}
                  isFullscreen={isFullscreen}
                />
              </div>
            </div>

            {/* Player Controls */}
            <div className="px-4 lg:px-6 pb-4">
              <div className="max-w-6xl mx-auto">
                <PlayerControls
                  onPrevious={handlePrevious}
                  onNext={handleNext}
                  onShuffle={handleShuffle}
                  onRepeat={handleRepeat}
                  onPlaybackSpeed={setPlaybackSpeed}
                  onQuality={setQuality}
                  isShuffled={isShuffled}
                  repeatMode={repeatMode}
                  playbackSpeed={playbackSpeed}
                  quality={quality}
                  canGoPrevious={currentVideoIndex > 0 || repeatMode === 'all'}
                  canGoNext={currentVideoIndex < videos?.length - 1 || repeatMode === 'all'}
                />
              </div>
            </div>

            {/* Video Metadata - Hidden on mobile when sidebar is open */}
            <div className={`px-4 lg:px-6 pb-6 ${!isSidebarCollapsed ? 'hidden lg:block' : ''}`}>
              <div className="max-w-6xl mx-auto">
                <VideoMetadata
                  video={currentVideo}
                  userNotes={userNotes}
                  onNotesChange={handleNotesChange}
                  onAddToPlaylist={handleAddToPlaylist}
                  onMarkFavorite={handleMarkFavorite}
                  onShare={handleShare}
                  isFavorite={false}
                  playlists={availablePlaylists}
                />
              </div>
            </div>
          </div>

          {/* Playlist Sidebar */}
          <div className={`${isSidebarCollapsed ? 'w-auto' : 'w-80'} flex-shrink-0 hidden lg:block`}>
            <PlaylistSidebar
              playlist={currentPlaylist}
              videos={videos}
              currentVideoIndex={currentVideoIndex}
              onVideoSelect={handleVideoSelect}
              onShuffle={handleShuffle}
              onRepeat={handleRepeat}
              isShuffled={isShuffled}
              repeatMode={repeatMode}
              isCollapsed={isSidebarCollapsed}
              onToggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
            />
          </div>
        </div>

        {/* Mobile Playlist Toggle */}
        <div className="lg:hidden fixed bottom-4 right-4 z-40">
          <Button
            variant="default"
            size="icon"
            className="w-12 h-12 rounded-full shadow-elevated"
            onClick={() => {
              // Toggle mobile playlist view
              console.log('Toggle mobile playlist');
            }}
          >
            <Icon name="List" size={20} />
          </Button>
        </div>

        {/* Mobile Navigation */}
        <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-card border-t border-border p-4">
          <div className="flex items-center justify-between max-w-sm mx-auto">
            <Button
              variant="ghost"
              size="icon"
              onClick={handlePrevious}
              disabled={currentVideoIndex === 0 && repeatMode !== 'all'}
            >
              <Icon name="SkipBack" size={20} />
            </Button>
            
            <Button
              variant="ghost"
              size="icon"
              onClick={handlePlayPause}
            >
              <Icon name={isPlaying ? "Pause" : "Play"} size={24} />
            </Button>
            
            <Button
              variant="ghost"
              size="icon"
              onClick={handleNext}
              disabled={currentVideoIndex === videos?.length - 1 && repeatMode !== 'all'}
            >
              <Icon name="SkipForward" size={20} />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VideoPlayerPage;